# Kids Quiz App

Bina login, bina apna server ke — poora offline quiz data (SharedPreferences me save hota hai).
Sirf **ads dikhane ke liye** internet chahiye (jaisa aapne bola tha).

## App Flow
1. **Select Class** → Class 1 se Class 10 tak
2. **Select Name** → bacche ka naam
3. **Select Language** → English / Hindi (aur bhasha add karna ho toh `res/values-XX/strings.xml` bana lena)
4. **Home** → upar profile chip (naam + class) — tap karke Class / Language / User badal sakte ho
5. **Quiz** → har level me 5 sawaal, 5/5 sahi karne par agla level unlock hota hai
6. **Level Map** → 1000 levels ka grid, jo unlock hain unhi par click ho sakta hai
7. **Result** → score dikhata hai, yahi pe interstitial (video) ad dikhti hai

## 2 Bhai, Ek Phone
Profile chip → "User Badlein" se naye profile add ho sakte hain. Har profile ka apna
naam, class, language, aur har class ke 1000 levels ka progress **alag-alag** save hota hai.

## Questions Kahan Se Aate Hain
- `app/src/main/assets/questions/class{N}_{lang}.json` — yahan real, hand-written
  sawaal daal sakte ho (format neeche diya hai). Abhi Class 1 English/Hindi ke
  Level 1-2 mein sample sawaal daale hain.
- Jis level ke liye JSON mein sawaal nahi milte, wahan app apne aap simple
  math sawaal generate kar deta hai — isliye **sabhi 1000 levels, sabhi class
  mein, turant kaam karte hain**, bina 1000 sawaal khud likhe.
- Jaise-jaise aap real sawaal JSON mein daalte jaoge, waise-waise woh JSON
  wale automatically procedural (auto-generated) sawaal ki jagah le lenge.

### JSON Format (naya level add karna ho toh copy karo)
```json
{
  "classId": 1,
  "language": "en",
  "levels": [
    {
      "level": 3,
      "questions": [
        { "question": "2 + 2 = ?", "options": ["3", "4", "5", "6"], "correctIndex": 1 }
      ]
    }
  ]
}
```
Har level mein 5 questions rakhna best hai (kyunki 5 sahi jawaab = 1 level up).

## Ads (AdMob)
- `AndroidManifest.xml` aur `AdManager.kt` mein abhi **Google ke TEST ad unit IDs**
  lage hain — app turant chalegi, lekin real paisa nahi milega.
- Real kamai ke liye:
  1. https://admob.google.com par account banao
  2. App add karo, Banner + Interstitial ad unit banao
  3. `AndroidManifest.xml` mein `APPLICATION_ID` badlo
  4. `AdManager.kt` mein `BANNER_AD_UNIT_ID` aur `INTERSTITIAL_AD_UNIT_ID` badlo
- **Ad placement** (taaki kisi ko dikkat na ho):
  - Banner: sirf Home aur Level Map screen ke bottom mein (chhota strip)
  - Interstitial (video ho sakta hai): sirf Result screen pe, level khatam
    hone ke baad — kabhi quiz ke beech mein nahi

## GitHub Se APK Kaise Banayein (bina Android Studio ke)

1. Yeh poora folder ek naye GitHub repository mein push kar do:
   ```
   git init
   git add .
   git commit -m "Kids Quiz App"
   git branch -M main
   git remote add origin https://github.com/<aapka-username>/<repo-name>.git
   git push -u origin main
   ```
2. GitHub par apne repo ke **"Actions"** tab mein jao — "Build APK" workflow
   apne aap chalna shuru ho jayega (2-4 minute lagte hain).
3. Workflow complete hone ke baad, us run ke andar **"Artifacts"** section
   mein `quiz-app-debug-apk` milega — usse download karo, andar `app-debug.apk` hoga.
4. Yeh APK apne phone mein bhej ke install kar lo (Unknown Sources allow karna padega).

> Ye Debug APK hai (turant test ke liye). Play Store pe daalne ke liye "release"
> build banani padegi jisme signing key chahiye hoga — agar aage chal ke chahiye
> ho toh bata dena, uska workflow bhi bana denge.

## Icons
Saare icons **Vector Drawables** hain (`res/drawable/ic_*.xml`) — yeh Android ka
SVG-jaisa hi format hai: resolution-independent, sharp har screen size par.

## Classes & Levels
- 10 classes (Class 1 – Class 10)
- Har class mein 1000 levels
- Total = 10,000 unique level-slots, sab offline available
