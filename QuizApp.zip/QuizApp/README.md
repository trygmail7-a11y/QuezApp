# Quiz Hub

Bina login, bina apna server ke — poora offline quiz data (SharedPreferences me save hota hai).
Sirf **video ads dikhane ke liye** internet chahiye.

## App Flow
1. **Select Class** → Class 1 se Class 10 tak
2. **Select Name** → bacche ka naam
3. **Select Language** → 6 languages (English, Hindi, Marathi, Bengali, Tamil, Telugu)
4. **Home** → hamburger menu (☰), profile chip (naam + class), current level+score card
   (jis subject par ho uske naam ke saath), "Levels" button, aur neeche 8 subjects ki list
5. Subject tap karte hi seedha quiz shuru ho jata hai
6. **Quiz** → har level me 5 sawaal, 2 hearts milte hain (2 galtiyon tak chalta hai)
7. **Result** → sahi kiya toh stars milte hain, ek video ad dekh ke agla level unlock hota hai
8. **Level Map** → 1000 levels ka grid, har level ke neeche uske stars (1-3) dikhte hain

## Hearts & Stars System
- Har level attempt me **2 hearts** milte hain (matlab 2 galat jawaab allowed hain)
- 3rd galti ho gayi (matlab 2 se zyada galat) → level turant **fail**, "Home/Retry" screen aata hai,
  koi ad nahi dikhti, progress aage nahi badhta
- Agar 5 sawaal poore ho gaye (max 2 galat ke saath):
  - 0 galat → **3 stars**
  - 1 galat → **2 stars**
  - 2 galat → **1 star**
- Stars Level Map me har level ke neeche dikhte hain (best score save hota hai)

## Subjects (har ek ke apne 1000 levels, har class ke liye alag)
Math, GK, SST, Biology, Reasoning, Computer, English, Hindi, **Remix** (sab subjects
ke sawaal mix karke) — total 9 subjects x 10 classes x 1000 levels.

## Question Repeat Na Ho (Fix)
- Ek baar jo sawaal kisi bhi level mein dikh chuka hai, wo dobara tab tak nahi aayega
  jab tak us subject ke pool ke saare sawaal ek baar use na ho jayein
- **Retry** karne par same level ke same sawaal hi dobara aayenge (jaisa expected hai)
- Naya level khelte waqt hamesha naye (ya sabse kam-dikhaye-gaye) sawaal milte hain
- Math procedurally generate hota hai isliye wo naturally kabhi repeat nahi hota

## Result Screen Ka Naya Logic
- **Level Pass ho gaya** (0-2 galat) → sirf "Next Level" button, koi ad nahi, seedha aage
- **Level Fail ho gaya** (2 se zyada galat) → "Try Again" (free) ya "Watch Video for Next
  Level" (ad dekh ke aage badh sakte ho, bina level pass kiye)
- Har subject me har 5 levels poore hone par ek automatic milestone video ad (sirf pass
  hone ki state mein)

## Level Map Mein Subject Switch
"Levels" screen ke andar upar ek subject-switcher row hai — waha se seedha kisi bhi
dusre subject ke levels dekh sakte ho, wapas Home jaane ki zaroorat nahi

## 5000+ Sawaal Per Subject Kaise Kaam Karta Hai
- **Math**: procedurally generate hota hai (numbers har baar badalte hain) — practically infinite
- **GK, SST, Biology, Reasoning, Computer, English, Hindi**: har subject mein ek curated
  "facts" list hai (jaise "Capital of India?" → Delhi), aur ek bada "distractor bank"
  (35-40 galat jawaab jaise Mumbai, Chennai, etc.) — in dono ko combine karke system
  automatically **5000+ unique combinations** bana leta hai (same sahi jawaab, alag-alag
  galat options ka set har baar) — yeh wahi tareeka hai jo bade quiz apps use karte hain
- **Remix**: sab 7 subjects ke expanded pools jod ke ek bada pool banata hai (35,000+)
- Dhyan rahe: sawaal ka **matn (text)** kabhi-kabhi dobara dikh sakta hai (jaise "Capital
  of India?" phir se), lekin uske 4 options ka set alag hoga — is wajah se ek hi sahi
  fact baar-baar theek se test hota hai bina fake/galat facts banaye
- Agar aap chahen toh `data/QuestionRepository.kt` mein `gkPool`, `sstPool` etc. list
  mein jitne chahein utne naye real facts add kar sakte ho — jitne zyada facts, utni
  zyada asli variety milegi

## Ads — Sirf 2 Jagah (jaisa maanga tha)
1. **Rewarded Video Ad** — Result screen pe, level poora karne ke baad, agla level unlock
   karne ke liye video dekhni hoti hai (agar ad na load ho — jaise internet na ho — toh bhi
   bacche ko aage badhne diya jata hai, taaki koi atke nahi)
2. **Milestone Video Ad** — har subject me har 5 levels poore hone par automatically ek
   interstitial (video-capable) ad dikhti hai
3. Koi banner ad kahin nahi hai — quiz solve karte waqt screen bilkul saaf rehti hai

Real AdMob IDs `AdManager.kt` mein daalne hain (`REWARDED_AD_UNIT_ID`, `MILESTONE_INTERSTITIAL_AD_UNIT_ID`)
— abhi Google ke TEST IDs lage hain.

## Hamburger Menu (☰, top-left)
Home, Privacy Policy, Terms & Conditions, About Us, Contact Us — yeh sab aapke diye hue
blogspot links khol dete hain:
- quizhubprivacy.blogspot.com
- quizhubterm.blogspot.com
- quizhubabout.blogspot.com
- quizhubcontact.blogspot.com

## Questions Kahan Se Aate Hain
`app/src/main/assets/questions/{subject}/class{N}_{lang}.json`
Jaise: `questions/math/class1_en.json`, `questions/gk/class3_hi.json` etc.

- Abhi sirf `math/class1_en.json` aur `math/class1_hi.json` me real (level 1-2) sawaal hain.
- Baaki jo level/subject/class ke liye JSON nahi milta, waha app automatically content
  generate kar leta hai (Math ke liye asli calculation, baaki subjects ke liye ek chhota
  sample question bank cycle hota hai) — taaki **sab 8000+ level-slots turant kaam karein**.
- Jaise-jaise aap real JSON files daalte jaoge, waise woh auto-generated content ki jagah le lenge.

### JSON Format
```json
{
  "classId": 1,
  "language": "en",
  "levels": [
    {
      "level": 3,
      "questions": [
        { "question": "2 + 2 = ?", "options": ["3", "4", "5", "6"], "correctIndex": 1 }
      ]
    }
  ]
}
```
Har level me 5 questions rakhna best hai.

## Logo
Aapka diya hua logo `mipmap-*` folders me sabhi densities me daal diya gaya hai
(app launcher icon ban chuka hai).

## GitHub Se APK Kaise Banayein
1. `.github/workflows/build-apk.yml` waisa hi rehne do (zip khud extract ho jayegi)
2. Poora `QuizApp.zip` seedha repo ke root me upload kar do
3. "Actions" tab me build khud chalega (3-5 min), "Artifacts" se APK download kar lena

## Release APK (Signed) vs Debug APK
Ab workflow **dono banata hai**:
- `quiz-app-debug-apk` — sirf testing ke liye
- `quiz-app-release-apk` — **yeh install/distribute karne wali asli APK hai**, already signed hai

**Keystore ke baare mein zaroori baat:**
- Maine ek signing keystore banayi hai (`keystore/quizhub-release.keystore`), jo repo ke andar hi hai
- Password: `quizhub123` (alias: `quizhub`) — yeh `app/build.gradle` mein already set hai, kuch karna nahi
- ⚠️ Agar aapka GitHub repo **Public** hai, toh yeh keystore bhi sabko dikhega — personal use ke liye koi badi baat nahi, lekin Play Store pe daalne se pehle repo ko **Private** kar lena behtar hai
- **Bahut zaroori**: is keystore ko kabhi mat delete/badalna — Play Store par publish hone ke baad HAR update isi keystore se sign honi chahiye, warna app update nahi ho paayegi

## Naya Class/Subject/Language Add Karna
- Classes: `SelectClassActivity.kt` aur `HomeActivity.kt` me `(1..10)` range badal do
- Subjects: `data/Subject.kt` me naya enum entry add karo + uska icon `drawable/` me daalo
- Languages: `util/LanguageManager.kt` me naya code+naam add karo, aur
  `res/values-{code}/strings.xml` bana ke translations daal do
