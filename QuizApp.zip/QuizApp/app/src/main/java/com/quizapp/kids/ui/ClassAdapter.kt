package com.quizapp.kids.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.quizapp.kids.R
import com.quizapp.kids.databinding.ItemClassBinding

class ClassAdapter(
    private val classNames: List<String>,
    private val onClick: (Int) -> Unit
) : RecyclerView.Adapter<ClassAdapter.ClassViewHolder>() {

    inner class ClassViewHolder(val binding: ItemClassBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ClassViewHolder {
        val binding = ItemClassBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ClassViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ClassViewHolder, position: Int) {
        holder.binding.textClassNumber.text = classNames[position]
        holder.binding.cardRoot.setOnClickListener { onClick(position + 1) }
    }

    override fun getItemCount(): Int = classNames.size
}
