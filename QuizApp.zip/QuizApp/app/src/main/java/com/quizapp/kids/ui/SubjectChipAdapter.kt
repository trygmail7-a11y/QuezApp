package com.quizapp.kids.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.quizapp.kids.R
import com.quizapp.kids.data.Subject
import com.quizapp.kids.databinding.ItemSubjectChipBinding

class SubjectChipAdapter(
    private val subjects: List<Subject>,
    private var selected: Subject,
    private val onSelect: (Subject) -> Unit
) : RecyclerView.Adapter<SubjectChipAdapter.ChipViewHolder>() {

    inner class ChipViewHolder(val binding: ItemSubjectChipBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChipViewHolder {
        val binding = ItemSubjectChipBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ChipViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ChipViewHolder, position: Int) {
        val subject = subjects[position]
        val context = holder.itemView.context
        holder.binding.chipIcon.setImageResource(subject.iconResId)
        holder.binding.chipText.text = context.getString(subject.nameResId)
        val isSelected = subject == selected
        holder.binding.chipRoot.setBackgroundResource(
            if (isSelected) R.drawable.bg_chip_selected else R.drawable.bg_chip_unselected
        )
        holder.binding.chipText.setTextColor(
            context.getColor(if (isSelected) R.color.white else R.color.text_primary)
        )
        holder.binding.chipRoot.setOnClickListener {
            if (subject != selected) {
                selected = subject
                notifyDataSetChanged()
                onSelect(subject)
            }
        }
    }

    override fun getItemCount(): Int = subjects.size
}
