package com.quizapp.kids.util

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

/**
 * Applies the chosen language to a Context. We call wrapContext() from
 * attachBaseContext() in every Activity so switching language per profile works
 * even though the app has no internet / no login — it's all local Configuration override.
 */
object LanguageManager {

    val supportedLanguages = listOf(
        "en" to "English",
        "hi" to "हिंदी (Hindi)",
        "mr" to "मराठी (Marathi)",
        "bn" to "বাংলা (Bengali)",
        "ta" to "தமிழ் (Tamil)",
        "te" to "తెలుగు (Telugu)"
    )

    fun wrapContext(context: Context, langCode: String): Context {
        val locale = Locale(langCode)
        Locale.setDefault(locale)
        val config = Configuration(context.resources.configuration)
        config.setLocale(locale)
        return context.createConfigurationContext(config)
    }
}
