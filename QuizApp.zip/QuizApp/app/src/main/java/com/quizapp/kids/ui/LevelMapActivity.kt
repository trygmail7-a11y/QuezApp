package com.quizapp.kids.ui

import android.content.Intent
import android.os.Bundle
import androidx.recyclerview.widget.GridLayoutManager
import com.quizapp.kids.data.ProfileManager
import com.quizapp.kids.databinding.ActivityLevelMapBinding
import com.quizapp.kids.util.AdManager

class LevelMapActivity : BaseActivity() {

    private lateinit var binding: ActivityLevelMapBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLevelMapBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val classId = intent.getIntExtra(QuizActivity.EXTRA_CLASS_ID, 1)
        val profileManager = ProfileManager(this)
        val name = profileManager.getCurrentProfileName() ?: return

        val highestUnlocked = profileManager.getHighestUnlockedLevel(name, classId)
        val currentLevel = profileManager.getCurrentLevel(name, classId)

        binding.recyclerLevels.layoutManager = GridLayoutManager(this, 5)
        binding.recyclerLevels.adapter = LevelAdapter(
            totalLevels = ProfileManager.MAX_LEVEL,
            highestUnlocked = highestUnlocked,
            currentLevel = currentLevel
        ) { level ->
            profileManager.jumpToLevel(name, classId, level)
            val intent = Intent(this, QuizActivity::class.java)
            intent.putExtra(QuizActivity.EXTRA_CLASS_ID, classId)
            intent.putExtra(QuizActivity.EXTRA_LEVEL, level)
            startActivity(intent)
        }

        binding.btnBack.setOnClickListener { finish() }

        AdManager.attachBanner(this, binding.bannerContainer)
    }
}
