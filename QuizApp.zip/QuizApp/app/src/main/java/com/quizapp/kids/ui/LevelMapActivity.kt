package com.quizapp.kids.ui

import android.content.Intent
import android.os.Bundle
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.quizapp.kids.data.ProfileManager
import com.quizapp.kids.data.Subject
import com.quizapp.kids.databinding.ActivityLevelMapBinding

class LevelMapActivity : BaseActivity() {

    private lateinit var binding: ActivityLevelMapBinding
    private lateinit var profileManager: ProfileManager
    private var classId = 1
    private lateinit var subject: Subject
    private var name = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLevelMapBinding.inflate(layoutInflater)
        setContentView(binding.root)

        profileManager = ProfileManager(this)
        subject = Subject.fromId(intent.getStringExtra(QuizActivity.EXTRA_SUBJECT) ?: Subject.MATH.id)
        classId = intent.getIntExtra(QuizActivity.EXTRA_CLASS_ID, 1)
        name = profileManager.getCurrentProfileName() ?: return

        binding.recyclerSubjectSwitcher.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        binding.recyclerSubjectSwitcher.adapter = SubjectChipAdapter(
            subjects = Subject.values().toList(),
            selected = subject
        ) { newSubject ->
            subject = newSubject
            profileManager.setCurrentSubject(name, newSubject)
            refreshLevelGrid()
        }

        binding.recyclerLevels.layoutManager = GridLayoutManager(this, 5)
        refreshLevelGrid()

        binding.btnBack.setOnClickListener { finish() }
    }

    private fun refreshLevelGrid() {
        binding.textLevelMapTitle.text = "${getString(subject.nameResId)} • Class $classId"

        val highestUnlocked = profileManager.getHighestUnlockedLevel(name, subject, classId)
        val currentLevel = profileManager.getCurrentLevel(name, subject, classId)

        binding.recyclerLevels.adapter = LevelAdapter(
            totalLevels = ProfileManager.MAX_LEVEL,
            highestUnlocked = highestUnlocked,
            currentLevel = currentLevel,
            starsForLevel = { level -> profileManager.getStarsForLevel(name, subject, classId, level) }
        ) { level ->
            profileManager.jumpToLevel(name, subject, classId, level)
            val intent = Intent(this, QuizActivity::class.java)
            intent.putExtra(QuizActivity.EXTRA_SUBJECT, subject.id)
            intent.putExtra(QuizActivity.EXTRA_CLASS_ID, classId)
            intent.putExtra(QuizActivity.EXTRA_LEVEL, level)
            startActivity(intent)
        }
    }
}
