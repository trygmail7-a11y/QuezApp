package com.quizapp.kids.ui

import android.content.Intent
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.quizapp.kids.data.ProfileManager
import com.quizapp.kids.databinding.ActivitySelectLanguageBinding
import com.quizapp.kids.util.LanguageManager

class SelectLanguageActivity : BaseActivity() {

    private lateinit var binding: ActivitySelectLanguageBinding
    private var classId: Int = -1
    private var name: String = ""
    private var selectedLang: String = "en"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySelectLanguageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        classId = intent.getIntExtra(SelectClassActivity.EXTRA_CLASS_ID, -1)
        name = intent.getStringExtra(SelectNameActivity.EXTRA_NAME).orEmpty()

        binding.btnBack.setOnClickListener { finish() }

        binding.recyclerLanguages.layoutManager = LinearLayoutManager(this)
        binding.recyclerLanguages.adapter = LanguageAdapter(LanguageManager.supportedLanguages, selectedLang) { code ->
            selectedLang = code
        }

        binding.btnContinue.setOnClickListener {
            val profileManager = ProfileManager(this)
            profileManager.setCurrentProfileName(name)
            profileManager.setProfileClass(name, classId)
            profileManager.setProfileLanguage(name, selectedLang)

            val intent = Intent(this, HomeActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }
    }
}
