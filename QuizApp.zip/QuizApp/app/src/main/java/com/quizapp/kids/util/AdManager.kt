package com.quizapp.kids.util

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.ads.*
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

/**
 * Central place for AdMob logic.
 *
 * Only TWO ad moments exist in the whole app:
 *  1) REWARDED VIDEO AD — shown on the Result screen when a level is FAILED, letting the
 *     child watch a video to skip ahead to the next level anyway.
 *  2) MILESTONE VIDEO AD (interstitial) — shown automatically every 5 completed levels
 *     within a subject, only on the success path.
 *
 * Every call here is wrapped defensively: if the device has no/old Google Play Services,
 * no internet, or the SDK misbehaves, we catch it and simply treat the ad as "not
 * available" so the rest of the app keeps working instead of crashing.
 */
object AdManager {

    private const val TAG = "AdManager"

    // Google's official TEST ad unit IDs - safe to ship while testing.
    // Replace with your real IDs from admob.google.com before release.
    const val REWARDED_AD_UNIT_ID = "ca-app-pub-3940256099942544/5224354917"
    const val MILESTONE_INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-3940256099942544/1033173712"

    private var rewardedAd: RewardedAd? = null
    private var milestoneAd: InterstitialAd? = null
    private var initialized = false

    fun init(context: Context) {
        if (initialized) return
        try {
            MobileAds.initialize(context) { initialized = true }
            preloadRewarded(context)
            preloadMilestone(context)
        } catch (e: Exception) {
            Log.d(TAG, "Ad init failed, ads will be unavailable: ${e.message}")
        }
    }

    private fun preloadRewarded(context: Context) {
        try {
            RewardedAd.load(
                context,
                REWARDED_AD_UNIT_ID,
                AdRequest.Builder().build(),
                object : RewardedAdLoadCallback() {
                    override fun onAdLoaded(ad: RewardedAd) {
                        rewardedAd = ad
                    }
                    override fun onAdFailedToLoad(error: LoadAdError) {
                        Log.d(TAG, "Rewarded ad failed to load: ${error.message}")
                        rewardedAd = null
                    }
                }
            )
        } catch (e: Exception) {
            Log.d(TAG, "Rewarded ad preload crashed safely: ${e.message}")
            rewardedAd = null
        }
    }

    private fun preloadMilestone(context: Context) {
        try {
            InterstitialAd.load(
                context,
                MILESTONE_INTERSTITIAL_AD_UNIT_ID,
                AdRequest.Builder().build(),
                object : InterstitialAdLoadCallback() {
                    override fun onAdLoaded(ad: InterstitialAd) {
                        milestoneAd = ad
                    }
                    override fun onAdFailedToLoad(error: LoadAdError) {
                        Log.d(TAG, "Milestone ad failed to load: ${error.message}")
                        milestoneAd = null
                    }
                }
            )
        } catch (e: Exception) {
            Log.d(TAG, "Milestone ad preload crashed safely: ${e.message}")
            milestoneAd = null
        }
    }

    /**
     * Shows the rewarded video ad. onRewardEarned is called ONLY if the user watched
     * it through to completion. If no ad is available, or the activity is no longer in
     * a valid state, or anything goes wrong with the SDK, onAdUnavailable is called
     * instead so the caller can safely continue without the ad.
     */
    fun showRewardedAd(activity: Activity, onRewardEarned: () -> Unit, onAdUnavailable: () -> Unit) {
        val ad = rewardedAd
        if (ad == null || activity.isFinishing || activity.isDestroyed) {
            onAdUnavailable()
            return
        }
        try {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    rewardedAd = null
                    preloadRewarded(activity)
                }
                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    rewardedAd = null
                    preloadRewarded(activity)
                    onAdUnavailable()
                }
            }
            ad.show(activity) { onRewardEarned() }
        } catch (e: Exception) {
            Log.d(TAG, "Showing rewarded ad crashed safely: ${e.message}")
            rewardedAd = null
            onAdUnavailable()
        }
    }

    /** Shows the milestone interstitial if ready. Always safe to call; no-op if not loaded. */
    fun showMilestoneAdIfReady(activity: Activity, onDismissed: () -> Unit) {
        val ad = milestoneAd
        if (ad == null || activity.isFinishing || activity.isDestroyed) {
            onDismissed()
            return
        }
        try {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    milestoneAd = null
                    preloadMilestone(activity)
                    onDismissed()
                }
                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    milestoneAd = null
                    preloadMilestone(activity)
                    onDismissed()
                }
            }
            ad.show(activity)
        } catch (e: Exception) {
            Log.d(TAG, "Showing milestone ad crashed safely: ${e.message}")
            milestoneAd = null
            onDismissed()
        }
    }
}
