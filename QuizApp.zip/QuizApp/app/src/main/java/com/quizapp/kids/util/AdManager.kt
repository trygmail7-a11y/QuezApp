package com.quizapp.kids.util

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.ads.*
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

/**
 * Central place for AdMob logic.
 *
 * Only TWO ad moments exist in the whole app (as requested):
 *  1) REWARDED VIDEO AD — shown on the Result screen after finishing a level.
 *     The child must watch it to unlock and move to the next level.
 *  2) MILESTONE VIDEO AD (interstitial) — shown automatically every 5 completed
 *     levels within a subject, as a short break.
 *
 * There is no banner ad anywhere, so nothing sits on screen distracting the child
 * during actual quiz-solving.
 *
 * IMPORTANT: replace TEST_* ids below with your real AdMob unit IDs before publishing.
 * Internet connection is required for ads to load (declared in AndroidManifest).
 */
object AdManager {

    private const val TAG = "AdManager"

    // Google's official TEST ad unit IDs - safe to ship while testing.
    // Replace with your real IDs from admob.google.com before release.
    const val REWARDED_AD_UNIT_ID = "ca-app-pub-3940256099942544/5224354917"
    const val MILESTONE_INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-3940256099942544/1033173712"

    private var rewardedAd: RewardedAd? = null
    private var milestoneAd: InterstitialAd? = null

    fun init(context: Context) {
        MobileAds.initialize(context) {}
        preloadRewarded(context)
        preloadMilestone(context)
    }

    private fun preloadRewarded(context: Context) {
        RewardedAd.load(
            context,
            REWARDED_AD_UNIT_ID,
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.d(TAG, "Rewarded ad failed to load: ${error.message}")
                    rewardedAd = null
                }
            }
        )
    }

    private fun preloadMilestone(context: Context) {
        InterstitialAd.load(
            context,
            MILESTONE_INTERSTITIAL_AD_UNIT_ID,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    milestoneAd = ad
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.d(TAG, "Milestone ad failed to load: ${error.message}")
                    milestoneAd = null
                }
            }
        )
    }

    /**
     * Shows the rewarded video ad. onRewardEarned is called ONLY if the user watched
     * it through to completion — that's when the next level should actually unlock.
     * If no ad is available (e.g. no internet), onAdUnavailable is called instead so
     * the app can decide what to do (in this app: unlock anyway, so kids are never stuck).
     */
    fun showRewardedAd(activity: Activity, onRewardEarned: () -> Unit, onAdUnavailable: () -> Unit) {
        val ad = rewardedAd
        if (ad == null) {
            onAdUnavailable()
            return
        }
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                rewardedAd = null
                preloadRewarded(activity)
            }
            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                rewardedAd = null
                preloadRewarded(activity)
                onAdUnavailable()
            }
        }
        ad.show(activity) { onRewardEarned() }
    }

    /** Shows the milestone interstitial if ready. Always safe to call; no-op if not loaded. */
    fun showMilestoneAdIfReady(activity: Activity, onDismissed: () -> Unit) {
        val ad = milestoneAd
        if (ad == null) {
            onDismissed()
            return
        }
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                milestoneAd = null
                preloadMilestone(activity)
                onDismissed()
            }
            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                milestoneAd = null
                preloadMilestone(activity)
                onDismissed()
            }
        }
        ad.show(activity)
    }
}
