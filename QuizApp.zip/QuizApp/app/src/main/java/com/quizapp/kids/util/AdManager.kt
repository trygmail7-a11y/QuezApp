package com.quizapp.kids.util

import android.app.Activity
import android.content.Context
import android.util.Log
import android.view.ViewGroup
import android.widget.FrameLayout
import com.google.android.gms.ads.*
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

/**
 * Central place for AdMob logic.
 *
 * Placement strategy (so kids/parents are never annoyed):
 *  - Banner ad: small strip at the BOTTOM of Home screen and Level Map screen only
 *    (never on the actual question screen, so it can't be mis-tapped mid-quiz).
 *  - Interstitial (full screen, can be video): shown ONLY on the Result screen,
 *    right after a level is finished — a natural break point — and never more
 *    than once per level completion.
 *
 * IMPORTANT: replace TEST_* ids below with your real AdMob unit IDs before publishing.
 * Internet connection is required for ads to load (declared in AndroidManifest).
 */
object AdManager {

    private const val TAG = "AdManager"

    // Google's official TEST ad unit IDs - safe to ship while testing.
    // Replace with your real IDs from admob.google.com before release.
    const val BANNER_AD_UNIT_ID = "ca-app-pub-3940256099942544/9214589741"
    const val INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-3940256099942544/1033173712"

    private var interstitialAd: InterstitialAd? = null

    fun init(context: Context) {
        MobileAds.initialize(context) {}
        preloadInterstitial(context)
    }

    /** Adds a banner ad into the given container at the bottom of a screen. */
    fun attachBanner(activity: Activity, container: FrameLayout) {
        val adView = AdView(activity)
        adView.adUnitId = BANNER_AD_UNIT_ID
        adView.setAdSize(AdSize.BANNER)
        container.removeAllViews()
        container.addView(
            adView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { gravity = android.view.Gravity.CENTER }
        )
        adView.loadAd(AdRequest.Builder().build())
    }

    private fun preloadInterstitial(context: Context) {
        InterstitialAd.load(
            context,
            INTERSTITIAL_AD_UNIT_ID,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.d(TAG, "Interstitial failed to load: ${error.message}")
                    interstitialAd = null
                }
            }
        )
    }

    /** Shows the interstitial if ready (called on the Result screen only). Always safe to call. */
    fun showInterstitialIfReady(activity: Activity, onDismissed: () -> Unit) {
        val ad = interstitialAd
        if (ad == null) {
            onDismissed()
            return
        }
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                interstitialAd = null
                preloadInterstitial(activity)
                onDismissed()
            }
            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                interstitialAd = null
                preloadInterstitial(activity)
                onDismissed()
            }
        }
        ad.show(activity)
    }
}
