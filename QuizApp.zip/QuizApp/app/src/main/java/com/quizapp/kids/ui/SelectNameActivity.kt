package com.quizapp.kids.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import com.quizapp.kids.databinding.ActivitySelectNameBinding

class SelectNameActivity : BaseActivity() {

    private lateinit var binding: ActivitySelectNameBinding
    private var classId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySelectNameBinding.inflate(layoutInflater)
        setContentView(binding.root)

        classId = intent.getIntExtra(SelectClassActivity.EXTRA_CLASS_ID, -1)

        binding.btnBack.setOnClickListener { finish() }

        binding.btnContinue.setOnClickListener {
            val name = binding.editName.text?.toString()?.trim().orEmpty()
            if (name.isEmpty()) {
                Toast.makeText(this, "Naam likhna zaroori hai", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val intent = Intent(this, SelectLanguageActivity::class.java)
            intent.putExtra(SelectClassActivity.EXTRA_CLASS_ID, classId)
            intent.putExtra(EXTRA_NAME, name)
            startActivity(intent)
        }
    }

    companion object {
        const val EXTRA_NAME = "extra_name"
    }
}
