package com.quizapp.kids.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.quizapp.kids.databinding.ItemLanguageBinding

class LanguageAdapter(
    private val languages: List<Pair<String, String>>, // code to display name
    private var selectedCode: String,
    private val onSelect: (String) -> Unit
) : RecyclerView.Adapter<LanguageAdapter.LangViewHolder>() {

    inner class LangViewHolder(val binding: ItemLanguageBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LangViewHolder {
        val binding = ItemLanguageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return LangViewHolder(binding)
    }

    override fun onBindViewHolder(holder: LangViewHolder, position: Int) {
        val (code, name) = languages[position]
        holder.binding.textLanguageName.text = name
        holder.binding.radioSelected.isChecked = code == selectedCode
        holder.binding.rowRoot.setOnClickListener {
            selectedCode = code
            notifyDataSetChanged()
            onSelect(code)
        }
    }

    override fun getItemCount(): Int = languages.size
}
