package com.quizapp.kids.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.quizapp.kids.R
import com.quizapp.kids.data.ProfileManager
import com.quizapp.kids.data.Subject
import com.quizapp.kids.databinding.ActivityHomeBinding
import com.quizapp.kids.databinding.DialogMenuBinding
import com.quizapp.kids.databinding.DialogProfileBinding
import com.quizapp.kids.util.AdManager
import com.quizapp.kids.util.LanguageManager

class HomeActivity : BaseActivity() {

    private lateinit var binding: ActivityHomeBinding
    private lateinit var profileManager: ProfileManager
    private var currentName: String = ""
    private var currentClass: Int = -1
    private var currentSubject: Subject = Subject.MATH

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        profileManager = ProfileManager(this)
        AdManager.init(applicationContext)

        binding.profileChip.setOnClickListener { showProfileDialog() }
        binding.btnMenu.setOnClickListener { showMenuDialog() }
        binding.btnAllLevels.setOnClickListener { openLevelMap(currentSubject) }

        binding.recyclerSubjects.layoutManager = LinearLayoutManager(this)
    }

    override fun onResume() {
        super.onResume()
        loadProfile()
    }

    private fun loadProfile() {
        currentName = profileManager.getCurrentProfileName() ?: run {
            startActivity(Intent(this, SelectClassActivity::class.java))
            finish()
            return
        }
        currentClass = profileManager.getProfileClass(currentName)
        currentSubject = profileManager.getCurrentSubject(currentName)

        binding.textProfileInfo.text = "$currentName • Class $currentClass"
        refreshSubjectCard()
        setupSubjectList()
    }

    private fun refreshSubjectCard() {
        binding.imageSubjectIcon.setImageResource(currentSubject.iconResId)
        binding.textSubjectLabel.text = getString(currentSubject.nameResId)
        val level = profileManager.getCurrentLevel(currentName, currentSubject, currentClass)
        val score = profileManager.getTotalScore(currentName, currentSubject, currentClass)
        binding.textCurrentLevel.text = getString(R.string.home_level_of_subject, level)
        binding.textScore.text = score.toString()
    }

    private fun setupSubjectList() {
        binding.recyclerSubjects.adapter = SubjectAdapter(
            subjects = Subject.values().toList(),
            levelForSubject = { subject -> profileManager.getCurrentLevel(currentName, subject, currentClass) }
        ) { subject ->
            currentSubject = subject
            profileManager.setCurrentSubject(currentName, subject)
            refreshSubjectCard()
            openQuiz(subject)
        }
    }

    private fun openQuiz(subject: Subject) {
        val intent = Intent(this, QuizActivity::class.java)
        intent.putExtra(QuizActivity.EXTRA_SUBJECT, subject.id)
        intent.putExtra(QuizActivity.EXTRA_CLASS_ID, currentClass)
        intent.putExtra(
            QuizActivity.EXTRA_LEVEL,
            profileManager.getCurrentLevel(currentName, subject, currentClass)
        )
        startActivity(intent)
    }

    private fun openLevelMap(subject: Subject) {
        val intent = Intent(this, LevelMapActivity::class.java)
        intent.putExtra(QuizActivity.EXTRA_SUBJECT, subject.id)
        intent.putExtra(QuizActivity.EXTRA_CLASS_ID, currentClass)
        startActivity(intent)
    }

    // ---------- Profile bottom sheet: change class / language / switch user ----------

    private fun showProfileDialog() {
        val sheetBinding = DialogProfileBinding.inflate(layoutInflater)
        val dialog = BottomSheetDialog(this)
        dialog.setContentView(sheetBinding.root)

        sheetBinding.textAvatarInitial.text = currentName.take(1).uppercase()
        sheetBinding.textDialogName.text = currentName
        sheetBinding.textDialogClass.text = "Class $currentClass"

        sheetBinding.rowChangeClass.setOnClickListener {
            dialog.dismiss()
            showChangeClassDialog()
        }
        sheetBinding.rowChangeLanguage.setOnClickListener {
            dialog.dismiss()
            showChangeLanguageDialog()
        }
        sheetBinding.rowSwitchUser.setOnClickListener {
            dialog.dismiss()
            showSwitchUserDialog()
        }
        dialog.show()
    }

    private fun showChangeClassDialog() {
        val classNames = (1..10).map { "Class $it" }.toTypedArray()
        val currentIndex = (currentClass - 1).coerceIn(0, 9)
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.profile_change_class))
            .setSingleChoiceItems(classNames, currentIndex) { dialog, which ->
                val newClass = which + 1
                profileManager.setProfileClass(currentName, newClass)
                currentClass = newClass
                loadProfile()
                dialog.dismiss()
            }
            .show()
    }

    private fun showChangeLanguageDialog() {
        val languages = LanguageManager.supportedLanguages
        val names = languages.map { it.second }.toTypedArray()
        val currentCode = profileManager.getProfileLanguage(currentName)
        val currentIndex = languages.indexOfFirst { it.first == currentCode }.coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.profile_change_language))
            .setSingleChoiceItems(names, currentIndex) { dialog, which ->
                profileManager.setProfileLanguage(currentName, languages[which].first)
                dialog.dismiss()
                recreate()
            }
            .show()
    }

    private fun showSwitchUserDialog() {
        val existing = profileManager.getAllProfileNames().toMutableList()
        existing.remove(currentName)
        val addNewLabel = getString(R.string.profile_add_user)
        val options = (existing + addNewLabel).toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.profile_change_user))
            .setItems(options) { _, which ->
                if (which == options.size - 1) {
                    startActivity(Intent(this, SelectClassActivity::class.java))
                } else {
                    val selected = existing[which]
                    profileManager.setCurrentProfileName(selected)
                    recreate()
                }
            }
            .show()
    }

    // ---------- Hamburger menu: Home / Privacy / Terms / About / Contact ----------

    private fun showMenuDialog() {
        val menuBinding = DialogMenuBinding.inflate(layoutInflater)
        val dialog = BottomSheetDialog(this)
        dialog.setContentView(menuBinding.root)

        menuBinding.rowMenuHome.setOnClickListener { dialog.dismiss() }
        menuBinding.rowMenuPrivacy.setOnClickListener {
            dialog.dismiss(); openWebLink("https://quizhubprivacy.blogspot.com")
        }
        menuBinding.rowMenuTerms.setOnClickListener {
            dialog.dismiss(); openWebLink("https://quizhubterm.blogspot.com")
        }
        menuBinding.rowMenuAbout.setOnClickListener {
            dialog.dismiss(); openWebLink("https://quizhubabout.blogspot.com")
        }
        menuBinding.rowMenuContact.setOnClickListener {
            dialog.dismiss(); openWebLink("https://quizhubcontact.blogspot.com")
        }
        dialog.show()
    }

    private fun openWebLink(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            // no browser available - fail silently, nothing to crash over
        }
    }
}
