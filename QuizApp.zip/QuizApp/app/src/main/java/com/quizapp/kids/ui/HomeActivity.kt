package com.quizapp.kids.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import com.quizapp.kids.data.ProfileManager
import com.quizapp.kids.databinding.ActivityHomeBinding
import com.quizapp.kids.util.AdManager
import com.quizapp.kids.util.LanguageManager

class HomeActivity : BaseActivity() {

    private lateinit var binding: ActivityHomeBinding
    private lateinit var profileManager: ProfileManager
    private var currentName: String = ""
    private var currentClass: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        profileManager = ProfileManager(this)

        binding.profileChip.setOnClickListener { showProfileMenu() }
        binding.btnStartQuiz.setOnClickListener { openQuiz() }
        binding.btnAllLevels.setOnClickListener { openLevelMap() }

        AdManager.attachBanner(this, binding.bannerContainer)
    }

    override fun onResume() {
        super.onResume()
        loadProfile()
    }

    private fun loadProfile() {
        currentName = profileManager.getCurrentProfileName() ?: run {
            startActivity(Intent(this, SelectClassActivity::class.java))
            finish()
            return
        }
        currentClass = profileManager.getProfileClass(currentName)

        binding.textProfileInfo.text = "$currentName • Class $currentClass"
        val level = profileManager.getCurrentLevel(currentName, currentClass)
        val score = profileManager.getTotalScore(currentName, currentClass)
        binding.textCurrentLevel.text = "Level $level"
        binding.textScore.text = score.toString()
    }

    private fun openQuiz() {
        val intent = Intent(this, QuizActivity::class.java)
        intent.putExtra(QuizActivity.EXTRA_CLASS_ID, currentClass)
        intent.putExtra(
            QuizActivity.EXTRA_LEVEL,
            profileManager.getCurrentLevel(currentName, currentClass)
        )
        startActivity(intent)
    }

    private fun openLevelMap() {
        val intent = Intent(this, LevelMapActivity::class.java)
        intent.putExtra(QuizActivity.EXTRA_CLASS_ID, currentClass)
        startActivity(intent)
    }

    // ---------- Profile menu: change class / change language / switch or add user ----------

    private fun showProfileMenu() {
        val options = arrayOf(
            getString(com.quizapp.kids.R.string.profile_change_class),
            getString(com.quizapp.kids.R.string.profile_change_language),
            getString(com.quizapp.kids.R.string.profile_change_user)
        )
        AlertDialog.Builder(this)
            .setTitle(currentName)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> showChangeClassDialog()
                    1 -> showChangeLanguageDialog()
                    2 -> showSwitchUserDialog()
                }
            }
            .show()
    }

    private fun showChangeClassDialog() {
        val classNames = (1..10).map { "Class $it" }.toTypedArray()
        val currentIndex = (currentClass - 1).coerceIn(0, 9)
        AlertDialog.Builder(this)
            .setTitle(getString(com.quizapp.kids.R.string.profile_change_class))
            .setSingleChoiceItems(classNames, currentIndex) { dialog, which ->
                val newClass = which + 1
                profileManager.setProfileClass(currentName, newClass)
                currentClass = newClass
                loadProfile()
                dialog.dismiss()
            }
            .show()
    }

    private fun showChangeLanguageDialog() {
        val languages = LanguageManager.supportedLanguages
        val names = languages.map { it.second }.toTypedArray()
        val currentCode = profileManager.getProfileLanguage(currentName)
        val currentIndex = languages.indexOfFirst { it.first == currentCode }.coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle(getString(com.quizapp.kids.R.string.profile_change_language))
            .setSingleChoiceItems(names, currentIndex) { dialog, which ->
                profileManager.setProfileLanguage(currentName, languages[which].first)
                dialog.dismiss()
                recreate() // reload with new locale
            }
            .show()
    }

    private fun showSwitchUserDialog() {
        val existing = profileManager.getAllProfileNames().toMutableList()
        existing.remove(currentName)
        val addNewLabel = "+ Naya User Add Karein"
        val options = (existing + addNewLabel).toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(getString(com.quizapp.kids.R.string.profile_change_user))
            .setItems(options) { _, which ->
                if (which == options.size - 1) {
                    startActivity(Intent(this, SelectClassActivity::class.java))
                } else {
                    val selected = existing[which]
                    profileManager.setCurrentProfileName(selected)
                    recreate()
                }
            }
            .show()
    }
}
