package com.quizapp.kids.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.quizapp.kids.data.Subject
import com.quizapp.kids.databinding.ItemSubjectBinding

class SubjectAdapter(
    private val subjects: List<Subject>,
    private val levelForSubject: (Subject) -> Int,
    private val onClick: (Subject) -> Unit
) : RecyclerView.Adapter<SubjectAdapter.SubjectViewHolder>() {

    inner class SubjectViewHolder(val binding: ItemSubjectBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SubjectViewHolder {
        val binding = ItemSubjectBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return SubjectViewHolder(binding)
    }

    override fun onBindViewHolder(holder: SubjectViewHolder, position: Int) {
        val subject = subjects[position]
        val context = holder.itemView.context
        holder.binding.imageSubjectIcon.setImageResource(subject.iconResId)
        holder.binding.textSubjectName.text = context.getString(subject.nameResId)
        holder.binding.textSubjectLevel.text =
            context.getString(com.quizapp.kids.R.string.home_level_of_subject, levelForSubject(subject))
        holder.binding.rowRoot.setOnClickListener { onClick(subject) }
    }

    override fun getItemCount(): Int = subjects.size
}
