package com.quizapp.kids.data

import com.quizapp.kids.R

/**
 * All quiz subjects. Each has its own 1000 levels per class, its own progress,
 * and its own icon shown on the Home screen subject picker.
 */
enum class Subject(val id: String, val nameResId: Int, val iconResId: Int) {
    MATH("math", R.string.subject_math, R.drawable.ic_subject_math),
    GK("gk", R.string.subject_gk, R.drawable.ic_subject_gk),
    SST("sst", R.string.subject_sst, R.drawable.ic_subject_sst),
    BIOLOGY("biology", R.string.subject_biology, R.drawable.ic_subject_biology),
    REASONING("reasoning", R.string.subject_reasoning, R.drawable.ic_subject_reasoning),
    COMPUTER("computer", R.string.subject_computer, R.drawable.ic_subject_computer),
    ENGLISH("english", R.string.subject_english, R.drawable.ic_subject_english),
    HINDI("hindi", R.string.subject_hindi, R.drawable.ic_subject_hindi),
    REMIX("remix", R.string.subject_remix, R.drawable.ic_subject_remix);

    companion object {
        fun fromId(id: String): Subject = values().find { it.id == id } ?: MATH
    }
}
