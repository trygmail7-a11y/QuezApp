package com.quizapp.kids.data

import android.content.Context
import com.google.gson.Gson
import kotlin.random.Random

/**
 * Loads questions for a given Subject + Class + Language + Level.
 *
 * Priority:
 * 1) A level that was already played before ALWAYS returns the same cached question
 *    set (so retrying a level shows the same questions again, as expected).
 * 2) Hand-written questions from assets/questions/{subject}/class{N}_{lang}.json
 *    (best quality — add as many levels as you want, see README for format).
 * 3) Otherwise, a fresh set is picked from a subject question pool WITHOUT repeating
 *    any question the child has already seen in that subject — until the whole pool
 *    has been used once, at which point it cycles again. Math questions are generated
 *    procedurally so they are naturally varied level to level.
 */
class QuestionRepository(private val context: Context, private val profileManager: ProfileManager) {

    private val gson = Gson()
    private val cache = HashMap<String, ClassQuestionBank?>()

    private fun loadBank(subject: Subject, classId: Int, language: String): ClassQuestionBank? {
        val key = "${subject.id}_${classId}_$language"
        if (cache.containsKey(key)) return cache[key]
        val bank = try {
            val fileName = "questions/${subject.id}/class${classId}_${language}.json"
            val json = context.assets.open(fileName).bufferedReader().use { it.readText() }
            gson.fromJson(json, ClassQuestionBank::class.java)
        } catch (e: Exception) {
            null
        }
        cache[key] = bank
        return bank
    }

    fun getLevel(subject: Subject, classId: Int, language: String, level: Int, profileName: String): LevelData {
        // 1) Already played this exact level before? Always return the same set (retry consistency).
        profileManager.getCachedLevelQuestions(profileName, subject, classId, language, level)?.let {
            return LevelData(level, it)
        }

        // 2) Hand-written content for this level, if present.
        val bank = loadBank(subject, classId, language)
        val handWritten = bank?.levels?.find { it.level == level }
        if (handWritten != null && handWritten.questions.isNotEmpty()) {
            profileManager.saveCachedLevelQuestions(profileName, subject, classId, language, level, handWritten.questions)
            return handWritten
        }

        // 3) Freshly picked, non-repeating (until pool exhausted) fallback content.
        val questions = if (subject == Subject.MATH) {
            FallbackQuestionGenerator.generateMathQuestions(classId, level)
        } else {
            pickNonRepeatingQuestions(subject, classId, language, level, profileName)
        }
        profileManager.saveCachedLevelQuestions(profileName, subject, classId, language, level, questions)
        return LevelData(level, questions)
    }

    private fun pickNonRepeatingQuestions(
        subject: Subject,
        classId: Int,
        language: String,
        level: Int,
        profileName: String
    ): List<Question> {
        val fullPool = FallbackQuestionGenerator.poolFor(subject)
        if (fullPool.isEmpty()) return FallbackQuestionGenerator.generateMathQuestions(classId, level)

        // Group all option-variants by their question STEM (the actual question text).
        // This is the key fix: we pick unseen STEMS first, so the same question text
        // never repeats until every distinct question in the subject has been asked once.
        val groupedByStem = fullPool.groupBy { it.question }
        val allStems = groupedByStem.keys.toList()

        val usedStems = profileManager.getUsedQuestionHashes(profileName, subject, classId, language)
        var availableStems = allStems.filter { it !in usedStems }

        if (availableStems.size < QUESTIONS_PER_LEVEL) {
            profileManager.resetUsedQuestionHashes(profileName, subject, classId, language)
            availableStems = allStems
        }

        val rnd = Random(subject.id.hashCode() * 31L + classId * 100000L + level)
        val chosenStems = availableStems.shuffled(rnd).take(QUESTIONS_PER_LEVEL)
        val finalQuestions = chosenStems.map { stem ->
            val variants = groupedByStem.getValue(stem)
            variants[rnd.nextInt(variants.size)]
        }

        profileManager.markQuestionHashesUsed(profileName, subject, classId, language, chosenStems)
        return finalQuestions
    }

    companion object {
        private const val QUESTIONS_PER_LEVEL = ProfileManager.QUESTIONS_PER_LEVEL
    }
}

/**
 * Curated sample question pools + procedural math generation, used as fallback content
 * so every level always has something to show before real per-level JSON is authored.
 */
object FallbackQuestionGenerator {

    fun generateMathQuestions(classId: Int, level: Int): List<Question> {
        val seed = classId * 100000L + level
        val rnd = Random(seed)
        val maxNumber = (10 + classId * 8 + level / 4).coerceAtMost(9999)
        return (1..5).map { generateMathQuestion(rnd, maxNumber) }
    }

    private fun generateMathQuestion(rnd: Random, maxNumber: Int): Question {
        val a = rnd.nextInt(1, maxNumber)
        val b = rnd.nextInt(1, maxNumber)
        val opPick = rnd.nextInt(0, 3)
        val (text, correct) = when (opPick) {
            0 -> "$a + $b = ?" to (a + b)
            1 -> {
                val big = maxOf(a, b); val small = minOf(a, b)
                "$big - $small = ?" to (big - small)
            }
            else -> {
                val s1 = rnd.nextInt(1, 12); val s2 = rnd.nextInt(1, 12)
                "$s1 x $s2 = ?" to (s1 * s2)
            }
        }
        val options = mutableListOf(correct)
        while (options.size < 4) {
            val delta = rnd.nextInt(-5, 6)
            val candidate = correct + delta + if (delta == 0) rnd.nextInt(1, 4) else 0
            if (candidate >= 0 && !options.contains(candidate)) options.add(candidate)
        }
        options.shuffle(rnd)
        return Question(
            question = text,
            options = options.map { it.toString() },
            correctIndex = options.indexOf(correct)
        )
    }

    val gkPool = listOf(
        Question("What is the capital of India?", listOf("Mumbai", "Delhi", "Chennai", "Kolkata"), 1),
        Question("Which is the largest continent?", listOf("Africa", "Asia", "Europe", "Australia"), 1),
        Question("How many planets are in our solar system?", listOf("7", "8", "9", "10"), 1),
        Question("Which is the national bird of India?", listOf("Sparrow", "Peacock", "Crow", "Eagle"), 1),
        Question("Which river is the longest in the world?", listOf("Ganga", "Amazon", "Nile", "Yamuna"), 2),
        Question("Which is the national animal of India?", listOf("Lion", "Tiger", "Elephant", "Leopard"), 1),
        Question("Which is the smallest country in the world?", listOf("Monaco", "Vatican City", "Malta", "Nauru"), 1),
        Question("Which planet is known as the Red Planet?", listOf("Venus", "Mars", "Jupiter", "Saturn"), 1),
        Question("Which is the tallest mountain in the world?", listOf("K2", "Everest", "Kangchenjunga", "Makalu"), 1),
        Question("Which gas do humans need to breathe?", listOf("Carbon Dioxide", "Oxygen", "Nitrogen", "Hydrogen"), 1),
        Question("How many continents are there?", listOf("5", "6", "7", "8"), 2),
        Question("Which is the largest ocean?", listOf("Atlantic", "Indian", "Pacific", "Arctic"), 2),
        Question("Which country is known as the Land of the Rising Sun?", listOf("China", "Japan", "Korea", "Thailand"), 1),
        Question("What is the national sport of India?", listOf("Cricket", "Football", "Hockey", "Kabaddi"), 2),
        Question("Which fruit is known as the King of Fruits?", listOf("Apple", "Banana", "Mango", "Grapes"), 2),
        Question("Which is the fastest land animal?", listOf("Lion", "Cheetah", "Horse", "Tiger"), 1),
        Question("Which day is celebrated as Independence Day in India?", listOf("15 August", "26 January", "2 October", "14 November"), 0),
        Question("Which is the largest mammal in the world?", listOf("Elephant", "Blue Whale", "Giraffe", "Shark"), 1),
        Question("Which is the smallest planet in our solar system?", listOf("Mercury", "Mars", "Venus", "Pluto"), 0),
        Question("How many colors are there in a rainbow?", listOf("5", "6", "7", "9"), 2),
        Question("Which bird cannot fly?", listOf("Sparrow", "Ostrich", "Eagle", "Parrot"), 1),
        Question("Which is the largest desert in the world?", listOf("Thar", "Sahara", "Gobi", "Kalahari"), 1),
        Question("Which country gifted the Statue of Liberty to the USA?", listOf("England", "France", "Spain", "Italy"), 1),
        Question("Which is the tallest animal in the world?", listOf("Elephant", "Giraffe", "Camel", "Horse"), 1),
        Question("Which metal is liquid at room temperature?", listOf("Iron", "Mercury", "Gold", "Silver"), 1),
        Question("How many legs does a spider have?", listOf("6", "8", "10", "12"), 1),
        Question("Which is the closest planet to the Sun?", listOf("Venus", "Earth", "Mercury", "Mars"), 2),
        Question("Which is the largest bird in the world?", listOf("Eagle", "Ostrich", "Peacock", "Crow"), 1),
        Question("Which festival is known as the festival of lights?", listOf("Holi", "Diwali", "Eid", "Christmas"), 1),
        Question("Which is the coldest continent?", listOf("Asia", "Europe", "Antarctica", "Africa"), 2),
        Question("How many sides does a hexagon have?", listOf("5", "6", "7", "8"), 1),
        Question("Which sea creature has 8 arms?", listOf("Starfish", "Octopus", "Jellyfish", "Crab"), 1),
        Question("Which is the hardest natural substance on Earth?", listOf("Gold", "Iron", "Diamond", "Silver"), 2),
        Question("Which vegetable is known for making you cry when cutting?", listOf("Potato", "Onion", "Carrot", "Tomato"), 1),
        Question("How many hours are there in a day?", listOf("12", "20", "24", "26"), 2),
        Question("Which is the tallest waterfall in the world?", listOf("Niagara Falls", "Angel Falls", "Victoria Falls", "Jog Falls"), 1),
        Question("Which is the largest island in the world?", listOf("Greenland", "Madagascar", "Borneo", "Sumatra"), 0),
        Question("Which planet has the most moons?", listOf("Earth", "Mars", "Saturn", "Mercury"), 2),
        Question("Which is the smallest bone in the human body?", listOf("Femur", "Stapes", "Radius", "Tibia"), 1),
        Question("Which country has the largest population in the world?", listOf("USA", "India", "China", "Russia"), 1),
        Question("Which is the longest river in Asia?", listOf("Ganga", "Yangtze", "Mekong", "Indus"), 1),
        Question("What is the boiling point of water in Celsius?", listOf("90", "100", "110", "120"), 1),
        Question("Which is the largest coral reef system in the world?", listOf("Red Sea Reef", "Great Barrier Reef", "Belize Reef", "Coral Triangle"), 1),
        Question("Which planet is known for its rings?", listOf("Mars", "Saturn", "Mercury", "Neptune"), 1),
        Question("Which is the deepest ocean trench?", listOf("Java Trench", "Mariana Trench", "Tonga Trench", "Peru Trench"), 1),
        Question("Which animal is known as the Ship of the Desert?", listOf("Horse", "Camel", "Donkey", "Elephant"), 1),
        Question("Which is the fastest bird in the world?", listOf("Eagle", "Peregrine Falcon", "Ostrich", "Hawk"), 1),
        Question("What is the freezing point of water in Celsius?", listOf("-10", "0", "10", "5"), 1),
        Question("Which is the largest freshwater lake in the world?", listOf("Lake Victoria", "Lake Superior", "Lake Baikal", "Lake Tanganyika"), 1),
        Question("Which gas makes up most of Earth's atmosphere?", listOf("Oxygen", "Nitrogen", "Carbon Dioxide", "Hydrogen"), 1),
        Question("Which country is known as the Land of a Thousand Lakes?", listOf("Norway", "Finland", "Sweden", "Iceland"), 1),
        Question("Which is the smallest continent by area?", listOf("Europe", "Australia", "Antarctica", "South America"), 1),
        Question("Which animal has the longest lifespan?", listOf("Elephant", "Tortoise", "Whale", "Parrot"), 1),
        Question("Which is the most spoken language in the world?", listOf("English", "Mandarin Chinese", "Spanish", "Hindi"), 1),
        Question("Which country invented paper?", listOf("India", "China", "Egypt", "Greece"), 1),
        Question("Which is the largest flower in the world?", listOf("Sunflower", "Rafflesia", "Lily", "Rose"), 1),
        Question("Which is the coldest place on Earth?", listOf("Siberia", "Antarctica", "Alaska", "Greenland"), 1),
        Question("Which sport is called the 'Gentleman's Game'?", listOf("Football", "Cricket", "Hockey", "Tennis"), 1),
        Question("Which country hosted the first modern Olympic Games?", listOf("France", "Greece", "Italy", "England"), 1),
        Question("How many players are there in a football team on the field?", listOf("9", "10", "11", "12"), 2),
        Question("Which country is famous for the Pyramids?", listOf("India", "Egypt", "Mexico", "Peru"), 1),
        Question("Which is the largest desert (including cold deserts) in the world?", listOf("Sahara", "Antarctic Desert", "Gobi", "Thar"), 1),
        Question("Which is the national flower of India?", listOf("Rose", "Lotus", "Sunflower", "Marigold"), 1),
        Question("Which insect produces silk?", listOf("Ant", "Silkworm", "Bee", "Butterfly"), 1),
        Question("Which is the largest planet in our solar system?", listOf("Earth", "Jupiter", "Saturn", "Neptune"), 1),
        Question("Which country is known as the Land of the Rising Sun?", listOf("China", "Japan", "Thailand", "Korea"), 1),
        Question("Which animal can change its skin color?", listOf("Frog", "Chameleon", "Lizard", "Snake"), 1),
        Question("Which is the busiest airport in the world (by passengers)?", listOf("JFK Airport", "Heathrow Airport", "Hartsfield-Jackson Atlanta", "Dubai Airport"), 2),
        Question("Which is the smallest ocean in the world?", listOf("Indian Ocean", "Arctic Ocean", "Atlantic Ocean", "Pacific Ocean"), 1),
        Question("Which country produces the most rice in the world?", listOf("India", "China", "Thailand", "Vietnam"), 1),
        Question("Which bird is known for mimicking human speech?", listOf("Sparrow", "Parrot", "Crow", "Pigeon"), 1),
        Question("Which is the tallest building in the world?", listOf("Burj Khalifa", "Shanghai Tower", "Eiffel Tower", "Empire State Building"), 0),
        Question("Which animal is known as man's best friend?", listOf("Cat", "Dog", "Horse", "Cow"), 1),
        Question("Which country has the most natural lakes?", listOf("USA", "Canada", "Russia", "Finland"), 1),
        Question("Which is the largest species of shark?", listOf("Great White Shark", "Whale Shark", "Hammerhead Shark", "Tiger Shark"), 1),
        Question("Which is the driest place on Earth?", listOf("Sahara Desert", "Atacama Desert", "Thar Desert", "Gobi Desert"), 1),
        Question("Which country is the largest by area?", listOf("China", "USA", "Russia", "Canada"), 2),
        Question("Which planet takes the longest time to orbit the Sun?", listOf("Saturn", "Uranus", "Neptune", "Jupiter"), 2),
        Question("Which is the tallest animal on land?", listOf("Elephant", "Giraffe", "Camel", "Horse"), 1),
        Question("Which season comes after winter?", listOf("Summer", "Spring", "Autumn", "Monsoon"), 1),
        Question("Which is the national tree of India?", listOf("Mango", "Banyan", "Neem", "Peepal"), 1),
        Question("Which animal is known for building dams?", listOf("Otter", "Beaver", "Squirrel", "Rabbit"), 1),
        Question("Which is the most populous city in the world?", listOf("Tokyo", "Delhi", "Shanghai", "Mumbai"), 0)
    )

    val sstPool = listOf(
        Question("Who was the first Prime Minister of India?", listOf("Gandhi", "Nehru", "Patel", "Bose"), 1),
        Question("In which year did India get independence?", listOf("1945", "1946", "1947", "1950"), 2),
        Question("Which is the largest state in India by area?", listOf("Rajasthan", "UP", "MP", "Maharashtra"), 0),
        Question("The Taj Mahal is located in which city?", listOf("Delhi", "Agra", "Jaipur", "Lucknow"), 1),
        Question("Which ocean is to the west of India?", listOf("Pacific", "Atlantic", "Arabian Sea", "Indian Ocean"), 2),
        Question("Who is known as the Father of the Nation in India?", listOf("Nehru", "Gandhi", "Bose", "Patel"), 1),
        Question("Which is the capital of Maharashtra?", listOf("Pune", "Nagpur", "Mumbai", "Nashik"), 2),
        Question("The Great Wall is located in which country?", listOf("Japan", "China", "India", "Korea"), 1),
        Question("Which is the longest river in India?", listOf("Yamuna", "Ganga", "Godavari", "Krishna"), 1),
        Question("Who wrote the Indian National Anthem?", listOf("Bankim Chandra", "Rabindranath Tagore", "Sarojini Naidu", "Iqbal"), 1),
        Question("Which is the smallest state in India by area?", listOf("Goa", "Sikkim", "Tripura", "Kerala"), 0),
        Question("How many states are there in India?", listOf("27", "28", "29", "31"), 1),
        Question("Which Mughal emperor built the Taj Mahal?", listOf("Akbar", "Shah Jahan", "Babur", "Aurangzeb"), 1),
        Question("Which is the currency of India?", listOf("Dollar", "Rupee", "Dinar", "Yen"), 1),
        Question("Who was the first President of India?", listOf("Nehru", "Rajendra Prasad", "Gandhi", "Patel"), 1),
        Question("Which is the capital of Gujarat?", listOf("Ahmedabad", "Surat", "Gandhinagar", "Vadodara"), 2),
        Question("Which movement did Gandhi lead against salt tax?", listOf("Quit India", "Salt March", "Non-Cooperation", "Swadeshi"), 1),
        Question("Which is the highest civilian award in India?", listOf("Padma Shri", "Padma Bhushan", "Bharat Ratna", "Ashoka Chakra"), 2),
        Question("Which ancient civilization existed near the Indus river?", listOf("Egyptian", "Indus Valley", "Roman", "Greek"), 1),
        Question("Which Indian city is known as the Pink City?", listOf("Jodhpur", "Udaipur", "Jaipur", "Jaisalmer"), 2),
        Question("Which is the national emblem of India based on?", listOf("Ashoka Pillar", "Red Fort", "Taj Mahal", "Qutub Minar"), 0),
        Question("Which continent is India located in?", listOf("Africa", "Asia", "Europe", "Australia"), 1),
        Question("Which Indian freedom fighter is known as Netaji?", listOf("Bhagat Singh", "Subhas Chandra Bose", "Nehru", "Tilak"), 1),
        Question("Which is the longest coastline state in India?", listOf("Kerala", "Gujarat", "Tamil Nadu", "Goa"), 1),
        Question("Which river is considered most sacred in India?", listOf("Yamuna", "Ganga", "Godavari", "Krishna"), 1),
        Question("Which is the largest desert in India?", listOf("Thar", "Kutch", "Rajasthan Desert", "Sahara"), 0),
        Question("Which Indian state is known as the Spice Garden of India?", listOf("Kerala", "Karnataka", "Tamil Nadu", "Goa"), 0),
        Question("Which is the highest mountain peak in India?", listOf("Nanda Devi", "Kangchenjunga", "K2", "Everest"), 1),
        Question("Which Mughal emperor was known as Akbar the Great?", listOf("Babur", "Humayun", "Akbar", "Jahangir"), 2),
        Question("Which city is known as the Silicon Valley of India?", listOf("Mumbai", "Bangalore", "Chennai", "Pune"), 1),
        Question("Which is the oldest civilisation in India?", listOf("Vedic", "Indus Valley", "Maurya", "Gupta"), 1),
        Question("Which battle established British rule in Bengal?", listOf("Battle of Panipat", "Battle of Plassey", "Battle of Buxar", "Battle of Haldighati"), 1),
        Question("Which Indian leader is called the Iron Man of India?", listOf("Nehru", "Gandhi", "Sardar Patel", "Bose"), 2),
        Question("Which is the smallest continent in the world?", listOf("Europe", "Australia", "Antarctica", "Asia"), 1),
        Question("Which river forms the Sundarbans delta?", listOf("Indus", "Ganga-Brahmaputra", "Godavari", "Krishna"), 1),
        Question("Which is the capital of Karnataka?", listOf("Mysore", "Bangalore", "Hubli", "Mangalore"), 1),
        Question("Which Indian dynasty built the Khajuraho temples?", listOf("Mauryas", "Chandelas", "Guptas", "Cholas"), 1),
        Question("Which is the largest religion in the world by followers?", listOf("Islam", "Christianity", "Hinduism", "Buddhism"), 1),
        Question("Which continent has the most countries?", listOf("Asia", "Africa", "Europe", "South America"), 1),
        Question("Which Indian state is the largest producer of tea?", listOf("Kerala", "Assam", "Karnataka", "Sikkim"), 1),
        Question("Who built the Red Fort in Delhi?", listOf("Akbar", "Shah Jahan", "Aurangzeb", "Humayun"), 1),
        Question("Which is the capital of Punjab?", listOf("Ludhiana", "Amritsar", "Chandigarh", "Patiala"), 2),
        Question("Which Indian state has the highest literacy rate?", listOf("Kerala", "Tamil Nadu", "Maharashtra", "Punjab"), 0),
        Question("Which country shares the longest border with India?", listOf("China", "Pakistan", "Bangladesh", "Nepal"), 2),
        Question("Which is the second most populous country in the world?", listOf("China", "India", "USA", "Indonesia"), 1),
        Question("Which Indian freedom fighter wrote 'Vande Mataram'?", listOf("Tagore", "Bankim Chandra Chatterjee", "Nehru", "Gandhi"), 1),
        Question("Which is the capital of Rajasthan?", listOf("Udaipur", "Jodhpur", "Jaipur", "Ajmer"), 2),
        Question("Which Indian city is called the City of Lakes?", listOf("Jaipur", "Udaipur", "Bhopal", "Srinagar"), 1),
        Question("Which was the first capital of India under British rule?", listOf("Delhi", "Kolkata", "Mumbai", "Chennai"), 1),
        Question("Which is the smallest state in India by population?", listOf("Sikkim", "Goa", "Tripura", "Mizoram"), 0),
        Question("Which Indian state is known as the Land of Five Rivers?", listOf("Haryana", "Punjab", "Rajasthan", "Gujarat"), 1),
        Question("Who is known as the architect of the Indian Constitution?", listOf("Nehru", "Gandhi", "B.R. Ambedkar", "Patel"), 2),
        Question("Which is the largest river basin in India?", listOf("Ganga", "Godavari", "Krishna", "Indus"), 0)
    )

    val biologyPool = listOf(
        Question("Which part of the plant makes food?", listOf("Root", "Stem", "Leaf", "Flower"), 2),
        Question("How many bones are in an adult human body?", listOf("196", "206", "216", "226"), 1),
        Question("Which organ pumps blood in our body?", listOf("Lungs", "Heart", "Kidney", "Liver"), 1),
        Question("Which gas do plants release during the day?", listOf("Carbon Dioxide", "Oxygen", "Nitrogen", "Hydrogen"), 1),
        Question("What do we call animals that eat only plants?", listOf("Carnivores", "Herbivores", "Omnivores", "Insectivores"), 1),
        Question("Which is the largest organ in the human body?", listOf("Liver", "Skin", "Heart", "Brain"), 1),
        Question("How many chambers does the human heart have?", listOf("2", "3", "4", "5"), 2),
        Question("Which blood cells fight infections?", listOf("Red blood cells", "White blood cells", "Platelets", "Plasma"), 1),
        Question("Which process do plants use to make food?", listOf("Respiration", "Photosynthesis", "Digestion", "Excretion"), 1),
        Question("What is the basic unit of life?", listOf("Tissue", "Organ", "Cell", "Molecule"), 2),
        Question("Which organ helps us breathe?", listOf("Heart", "Lungs", "Stomach", "Kidney"), 1),
        Question("Which vitamin do we get from sunlight?", listOf("Vitamin A", "Vitamin C", "Vitamin D", "Vitamin K"), 2),
        Question("Which animal is known as man's best friend?", listOf("Cat", "Dog", "Horse", "Cow"), 1),
        Question("What do we call baby frogs?", listOf("Cub", "Tadpole", "Calf", "Kitten"), 1),
        Question("Which organ helps us see?", listOf("Ear", "Eye", "Nose", "Skin"), 1),
        Question("Which is the powerhouse of the cell?", listOf("Nucleus", "Mitochondria", "Cytoplasm", "Membrane"), 1),
        Question("Which vitamin deficiency causes night blindness?", listOf("Vitamin A", "Vitamin B", "Vitamin C", "Vitamin D"), 0),
        Question("Which animal is a mammal but lays eggs?", listOf("Kangaroo", "Platypus", "Dolphin", "Bat"), 1),
        Question("Which is the largest gland in the human body?", listOf("Pancreas", "Liver", "Thyroid", "Pituitary"), 1),
        Question("Which body part filters waste from blood?", listOf("Liver", "Kidney", "Lungs", "Heart"), 1),
        Question("Which gas do we breathe out?", listOf("Oxygen", "Carbon Dioxide", "Nitrogen", "Hydrogen"), 1),
        Question("What is the study of living things called?", listOf("Physics", "Chemistry", "Biology", "Geology"), 2),
        Question("Which part of the eye controls how much light enters?", listOf("Retina", "Pupil", "Lens", "Cornea"), 1),
        Question("Which blood group is known as the universal donor?", listOf("A", "B", "AB", "O negative"), 3),
        Question("Which is the largest bone in the human body?", listOf("Femur", "Humerus", "Tibia", "Fibula"), 0),
        Question("Which organ produces insulin?", listOf("Liver", "Pancreas", "Kidney", "Stomach"), 1),
        Question("Which part of the plant absorbs water from the soil?", listOf("Leaf", "Stem", "Root", "Flower"), 2),
        Question("What is the function of red blood cells?", listOf("Fight infection", "Carry oxygen", "Clot blood", "Digest food"), 1),
        Question("Which sense organ helps us smell?", listOf("Eye", "Ear", "Nose", "Tongue"), 2),
        Question("Which gas is essential for photosynthesis?", listOf("Oxygen", "Carbon Dioxide", "Nitrogen", "Hydrogen"), 1),
        Question("How many pairs of ribs does a human have?", listOf("10", "12", "14", "16"), 1),
        Question("Which is the smallest unit of life?", listOf("Tissue", "Cell", "Organ", "Organism"), 1),
        Question("Which animal group do frogs belong to?", listOf("Mammals", "Amphibians", "Reptiles", "Birds"), 1),
        Question("Which part of the brain controls balance?", listOf("Cerebrum", "Cerebellum", "Medulla", "Hypothalamus"), 1),
        Question("Which vitamin helps in blood clotting?", listOf("Vitamin A", "Vitamin C", "Vitamin K", "Vitamin E"), 2),
        Question("Which is the longest bone in the human leg?", listOf("Tibia", "Fibula", "Femur", "Patella"), 2),
        Question("What do we call animals that eat both plants and animals?", listOf("Herbivores", "Carnivores", "Omnivores", "Insectivores"), 2),
        Question("Which organ is responsible for pumping blood?", listOf("Lungs", "Heart", "Liver", "Kidney"), 1),
        Question("Which is the outer layer of skin called?", listOf("Dermis", "Epidermis", "Hypodermis", "Cortex"), 1),
        Question("Which process do plants use to release water vapor?", listOf("Respiration", "Transpiration", "Photosynthesis", "Excretion"), 1),
        Question("Which is the main function of the skeletal system?", listOf("Digestion", "Support the body", "Pump blood", "Filter waste"), 1),
        Question("Which animal is cold-blooded?", listOf("Dog", "Snake", "Cat", "Horse"), 1),
        Question("Which part of a plant makes seeds?", listOf("Root", "Stem", "Fruit", "Leaf"), 2),
        Question("Which type of teeth are used for cutting food?", listOf("Molars", "Incisors", "Canines", "Premolars"), 1),
        Question("Which organ helps in digestion of food?", listOf("Heart", "Stomach", "Lungs", "Kidney"), 1),
        Question("Which is the largest internal organ in the human body?", listOf("Heart", "Liver", "Lungs", "Kidney"), 1),
        Question("How many teeth does an adult human have?", listOf("28", "30", "32", "34"), 2)
    )

    val reasoningPool = listOf(
        Question("Find the odd one out: 2, 4, 6, 9, 8", listOf("4", "9", "6", "8"), 1),
        Question("If A=1, B=2, C=3... what is E?", listOf("4", "5", "6", "7"), 1),
        Question("Complete: 2, 4, 8, 16, ?", listOf("18", "24", "32", "20"), 2),
        Question("Which shape has 3 sides?", listOf("Square", "Triangle", "Circle", "Pentagon"), 1),
        Question("Monday, Tuesday, Wednesday, ?", listOf("Friday", "Sunday", "Thursday", "Saturday"), 2),
        Question("Complete the series: 1, 4, 9, 16, ?", listOf("20", "25", "24", "22"), 1),
        Question("Which number comes next: 5, 10, 15, 20, ?", listOf("22", "25", "24", "30"), 1),
        Question("Find the odd one: Dog, Cat, Car, Cow", listOf("Dog", "Cat", "Car", "Cow"), 2),
        Question("If today is Monday, what day is after tomorrow?", listOf("Tuesday", "Wednesday", "Thursday", "Friday"), 1),
        Question("Which is heavier: 1 kg cotton or 1 kg iron?", listOf("Cotton", "Iron", "Both equal", "Cannot say"), 2),
        Question("Find the odd one out: Circle, Square, Triangle, Red", listOf("Circle", "Square", "Triangle", "Red"), 3),
        Question("Complete: A, C, E, G, ?", listOf("H", "I", "J", "K"), 1),
        Question("Find the odd one out: 3, 9, 27, 40, 81", listOf("9", "27", "40", "81"), 2),
        Question("If CAT is coded as DBU, how is DOG coded?", listOf("EPH", "EPI", "FPH", "EQH"), 0),
        Question("Which number is missing: 3, 6, 12, 24, ?", listOf("30", "36", "48", "42"), 2),
        Question("A clock shows 3:00. What angle do the hands make?", listOf("60", "90", "120", "180"), 1),
        Question("Find the odd one: Apple, Banana, Potato, Mango", listOf("Apple", "Banana", "Potato", "Mango"), 2),
        Question("If today is Friday, what was 3 days ago?", listOf("Monday", "Tuesday", "Wednesday", "Thursday"), 1),
        Question("Find the missing number: 2, 5, 10, 17, ?", listOf("24", "26", "28", "30"), 1),
        Question("Which comes next: Z, X, V, T, ?", listOf("S", "R", "Q", "P"), 1),
        Question("If 5+3=28, 9+1=810, then 6+4=?", listOf("102", "210", "610", "24"), 1),
        Question("Find the odd one: Triangle, Square, Circle, Red", listOf("Triangle", "Square", "Circle", "Red"), 3),
        Question("A is B's sister. B is C's brother. What is A to C?", listOf("Brother", "Sister", "Mother", "Aunt"), 1),
        Question("Complete the pattern: 1, 1, 2, 3, 5, 8, ?", listOf("11", "12", "13", "14"), 2),
        Question("Which number does not belong: 16, 25, 36, 40, 49", listOf("16", "25", "40", "49"), 2),
        Question("If North becomes East, what does East become?", listOf("North", "South", "West", "East"), 2),
        Question("Find the odd one: Rose, Lily, Lotus, Mango", listOf("Rose", "Lily", "Lotus", "Mango"), 3),
        Question("Complete: 100, 90, 80, 70, ?", listOf("50", "55", "60", "65"), 2),
        Question("Which word does not belong: Run, Walk, Jump, Table", listOf("Run", "Walk", "Jump", "Table"), 3),
        Question("If today is Sunday, what day will it be after 10 days?", listOf("Tuesday", "Wednesday", "Thursday", "Friday"), 1),
        Question("Which shape has no corners?", listOf("Square", "Triangle", "Circle", "Rectangle"), 2),
        Question("Find the missing letter: B, D, F, H, ?", listOf("I", "J", "K", "L"), 1),
        Question("Which number comes next: 1, 4, 9, 16, 25, ?", listOf("30", "36", "32", "34"), 1),
        Question("If all cats are animals, and Tom is a cat, then Tom is a...", listOf("Dog", "Animal", "Plant", "Bird"), 1),
        Question("Which is heavier, a kilogram of feathers or a kilogram of stones?", listOf("Feathers", "Stones", "Both equal", "Cannot say"), 2)
    )

    val computerPool = listOf(
        Question("What does CPU stand for?", listOf("Central Process Unit", "Central Processing Unit", "Computer Personal Unit", "Central Processor Unit"), 1),
        Question("Which of these is an input device?", listOf("Monitor", "Printer", "Keyboard", "Speaker"), 2),
        Question("What do we use to open a website?", listOf("Browser", "Compiler", "Editor", "Player"), 0),
        Question("Which key deletes a character to the left?", listOf("Delete", "Backspace", "Enter", "Shift"), 1),
        Question("A computer's memory is measured in?", listOf("Meters", "Bytes", "Litres", "Kilograms"), 1),
        Question("Which of these is an output device?", listOf("Keyboard", "Mouse", "Monitor", "Scanner"), 2),
        Question("What does WWW stand for?", listOf("World Wide Web", "World Wide Wire", "Web Wide World", "Wide World Web"), 0),
        Question("Which device is used to point and click?", listOf("Keyboard", "Mouse", "Monitor", "CPU"), 1),
        Question("What is the full form of RAM?", listOf("Random Access Memory", "Read Access Memory", "Random Active Memory", "Read Active Memory"), 0),
        Question("Which software helps us type documents?", listOf("Calculator", "Word Processor", "Browser", "Antivirus"), 1),
        Question("Which of these is a search engine?", listOf("Google", "Windows", "Word", "Excel"), 0),
        Question("What is used to save your work permanently?", listOf("RAM", "Save/Storage", "CPU", "Monitor"), 1),
        Question("Which of these is a programming language?", listOf("HTML", "Python", "Photoshop", "Excel"), 1),
        Question("What is the shortcut key to copy?", listOf("Ctrl+V", "Ctrl+C", "Ctrl+X", "Ctrl+Z"), 1),
        Question("Which device connects your computer to the internet?", listOf("Printer", "Router", "Speaker", "Monitor"), 1),
        Question("What does USB stand for?", listOf("Universal Serial Bus", "United Serial Bus", "Universal System Bus", "United System Bus"), 0),
        Question("Which folder stores deleted files temporarily?", listOf("Downloads", "Recycle Bin", "Documents", "Desktop"), 1),
        Question("Which of these is a social media platform?", listOf("Instagram", "Windows", "Linux", "MS Word"), 0),
        Question("What is the full form of PDF?", listOf("Portable Document Format", "Personal Document File", "Printed Document Format", "Public Data File"), 0),
        Question("Which company created the Windows operating system?", listOf("Apple", "Microsoft", "Google", "IBM"), 1),
        Question("Which symbol is used for email addresses?", listOf("#", "@", "&", "%"), 1),
        Question("What is a group of computers connected together called?", listOf("Server", "Network", "Hub", "Router"), 1),
        Question("Which of these is used to protect a computer from viruses?", listOf("Browser", "Antivirus", "Compiler", "Editor"), 1),
        Question("What does 'www' stand for in a website address?", listOf("World Wide Web", "World Wide Wire", "Wide World Web", "World Web Wide"), 0),
        Question("Which of these is a type of computer memory?", listOf("RAM", "CAM", "TAM", "FAM"), 0),
        Question("Which company created the iPhone?", listOf("Samsung", "Apple", "Google", "Sony"), 1),
        Question("What is the brain of the computer called?", listOf("RAM", "CPU", "Monitor", "Keyboard"), 1),
        Question("Which of these file types is used for images?", listOf(".doc", ".jpg", ".mp3", ".exe"), 1),
        Question("Which of these is an example of an operating system?", listOf("Android", "Chrome", "Facebook", "Word"), 0),
        Question("Which key is used to start a new line in a document?", listOf("Shift", "Enter", "Tab", "Ctrl"), 1),
        Question("What do we call unwanted emails?", listOf("Spam", "Draft", "Inbox", "Sent"), 0),
        Question("Which company owns Google Search?", listOf("Microsoft", "Alphabet", "Apple", "Amazon"), 1),
        Question("Which device is used to print documents?", listOf("Scanner", "Printer", "Monitor", "Speaker"), 1),
        Question("What is the full form of ATM?", listOf("Automated Teller Machine", "Automatic Transfer Machine", "Auto Task Machine", "Advanced Teller Machine"), 0),
        Question("Which of these is a web browser?", listOf("Chrome", "Windows", "Word", "Excel"), 0)
    )

    val englishPool = listOf(
        Question("Choose the correct spelling.", listOf("Recieve", "Receive", "Receeve", "Receve"), 1),
        Question("What is the plural of 'Child'?", listOf("Childs", "Childes", "Children", "Childrens"), 2),
        Question("Choose the synonym of 'Happy'.", listOf("Sad", "Angry", "Joyful", "Tired"), 2),
        Question("Which word is a noun?", listOf("Run", "Beautiful", "Table", "Quickly"), 2),
        Question("Fill in the blank: She ___ to school every day.", listOf("go", "goes", "going", "gone"), 1),
        Question("Choose the antonym of 'Big'.", listOf("Large", "Huge", "Small", "Tall"), 2),
        Question("Which is a verb?", listOf("Jump", "Table", "Blue", "Happy"), 0),
        Question("Which sentence is correct?", listOf("He go to school", "He goes to school", "He going school", "He gone school"), 1),
        Question("What is the opposite of 'Hot'?", listOf("Warm", "Cold", "Sunny", "Bright"), 1),
        Question("Choose the correct article: ___ apple", listOf("A", "An", "The", "No article"), 1),
        Question("Which word means the same as 'Fast'?", listOf("Slow", "Quick", "Lazy", "Heavy"), 1),
        Question("Which of these is an adjective?", listOf("Run", "Beautiful", "Quickly", "Table"), 1),
        Question("What is the past tense of 'Go'?", listOf("Goed", "Went", "Gone", "Going"), 1),
        Question("Choose the correctly punctuated sentence.", listOf("whats your name", "What's your name?", "whats your name?", "What's your name"), 1),
        Question("Which word is a pronoun?", listOf("She", "Run", "Quickly", "Table"), 0),
        Question("What is the opposite of 'Difficult'?", listOf("Hard", "Easy", "Tough", "Complex"), 1),
        Question("Choose the correct plural of 'Mouse' (animal).", listOf("Mouses", "Mice", "Mouse", "Meece"), 1),
        Question("Which sentence uses correct grammar?", listOf("She don't like it", "She doesn't likes it", "She doesn't like it", "She not like it"), 2),
        Question("What is the comparative form of 'Good'?", listOf("Gooder", "Better", "Best", "More good"), 1),
        Question("Which word is spelled correctly?", listOf("Definately", "Definitely", "Definitly", "Definetly"), 1),
        Question("Choose the correct preposition: The book is ___ the table.", listOf("in", "on", "at", "by"), 1),
        Question("What is the superlative form of 'Big'?", listOf("Bigger", "Biggest", "More big", "Most big"), 1),
        Question("Which of these is a proper noun?", listOf("city", "river", "India", "book"), 2),
        Question("Choose the correct sentence.", listOf("I is happy", "I am happy", "I be happy", "I are happy"), 1),
        Question("What is the plural of 'Tooth'?", listOf("Tooths", "Teeths", "Teeth", "Toothes"), 2),
        Question("Which word means the opposite of 'Above'?", listOf("Over", "Below", "Up", "High"), 1),
        Question("Choose the correct spelling.", listOf("Neccessary", "Necessary", "Neccesary", "Necesary"), 1),
        Question("Which is an example of a conjunction?", listOf("Run", "And", "Happy", "Table"), 1),
        Question("What is the past tense of 'Eat'?", listOf("Eated", "Ate", "Eaten", "Eating"), 1),
        Question("Choose the correct article: ___ umbrella", listOf("A", "An", "The", "No article"), 1),
        Question("Which word is an interjection?", listOf("Wow!", "Table", "Run", "Blue"), 0),
        Question("What is the plural of 'Man'?", listOf("Mans", "Men", "Manes", "Mens"), 1),
        Question("Choose the correct sentence.", listOf("He can sings well", "He can sing well", "He can singing well", "He cans sing well"), 1),
        Question("Which word rhymes with 'Cat'?", listOf("Dog", "Hat", "Cup", "Pen"), 1),
        Question("What is the plural of 'Leaf'?", listOf("Leafs", "Leaves", "Leafes", "Leaf"), 1)
    )

    val hindiPool = listOf(
        Question("'पुस्तक' का पर्यायवाची शब्द चुनें।", listOf("किताब", "कलम", "मेज़", "कुर्सी"), 0),
        Question("'बड़ा' का विलोम शब्द क्या है?", listOf("लंबा", "छोटा", "ऊँचा", "मोटा"), 1),
        Question("'राम खाना खाता है' — इसमें क्रिया कौन सी है?", listOf("राम", "खाना", "खाता है", "है"), 2),
        Question("हिंदी वर्णमाला में कितने स्वर होते हैं?", listOf("10", "11", "12", "13"), 1),
        Question("'सूर्य' का पर्यायवाची क्या है?", listOf("चाँद", "तारा", "रवि", "बादल"), 2),
        Question("'रात' का विलोम शब्द क्या है?", listOf("दिन", "सुबह", "शाम", "दोपहर"), 0),
        Question("'मीठा' का विलोम शब्द है?", listOf("खट्टा", "कड़वा", "नमकीन", "तीखा"), 1),
        Question("'गाय' शब्द किस लिंग का है?", listOf("पुल्लिंग", "स्त्रीलिंग", "नपुंसक", "कोई नहीं"), 1),
        Question("'पानी' का पर्यायवाची शब्द है?", listOf("जल", "अग्नि", "वायु", "मिट्टी"), 0),
        Question("हिंदी में कुल कितने व्यंजन होते हैं?", listOf("30", "33", "35", "40"), 1),
        Question("'फूल' का बहुवचन क्या है?", listOf("फूल", "फूलें", "फूलों", "फूला"), 2),
        Question("'वह पढ़ता है' में कौन सा शब्द क्रिया है?", listOf("वह", "पढ़ता है", "है", "इनमें से कोई नहीं"), 1),
        Question("'सुंदर' का विलोम शब्द क्या है?", listOf("अच्छा", "कुरूप", "प्यारा", "सुशील"), 1),
        Question("'हाथी' शब्द का पर्यायवाची क्या है?", listOf("गज", "अश्व", "सिंह", "व्याघ्र"), 0),
        Question("'अमीर' का विलोम शब्द क्या है?", listOf("धनी", "गरीब", "सुखी", "समृद्ध"), 1),
        Question("'वन' का पर्यायवाची शब्द क्या है?", listOf("जंगल", "पर्वत", "नदी", "मैदान"), 0),
        Question("संज्ञा के कितने भेद होते हैं?", listOf("2", "3", "5", "6"), 2),
        Question("'नयन' का पर्यायवाची क्या है?", listOf("आँख", "कान", "नाक", "मुँह"), 0),
        Question("'जल्दी' का विलोम शब्द क्या है?", listOf("तेज़", "धीरे", "फुर्ती", "शीघ्र"), 1),
        Question("'माता' का पर्यायवाची क्या है?", listOf("जननी", "बहन", "बेटी", "पत्नी"), 0),
        Question("हिंदी भाषा किस लिपि में लिखी जाती है?", listOf("रोमन", "देवनागरी", "उर्दू", "गुरुमुखी"), 1),
        Question("'सत्य' का विलोम शब्द क्या है?", listOf("झूठ", "ईमानदारी", "न्याय", "धर्म"), 0),
        Question("'आकाश' का पर्यायवाची शब्द क्या है?", listOf("गगन", "धरती", "सागर", "पाताल"), 0),
        Question("'कठिन' का विलोम शब्द क्या है?", listOf("सरल", "मुश्किल", "जटिल", "उलझा"), 0),
        Question("वचन के कितने भेद होते हैं?", listOf("2", "3", "4", "5"), 0),
        Question("'पिता' का पर्यायवाची क्या है?", listOf("जनक", "पुत्र", "भाई", "मामा"), 0),
        Question("'ऊपर' का विलोम शब्द क्या है?", listOf("आगे", "नीचे", "पीछे", "बगल"), 1),
        Question("'पर्वत' का पर्यायवाची शब्द क्या है?", listOf("पहाड़", "मैदान", "रेगिस्तान", "समुद्र"), 0)
    )

    private val poolsBySubject: Map<Subject, List<Question>> = mapOf(
        Subject.GK to gkPool,
        Subject.SST to sstPool,
        Subject.BIOLOGY to biologyPool,
        Subject.REASONING to reasoningPool,
        Subject.COMPUTER to computerPool,
        Subject.ENGLISH to englishPool,
        Subject.HINDI to hindiPool
    )

    // ---------- Distractor banks: shared wrong-answer options per subject, used to
    // combinatorially expand each curated question into MANY option-variants so that
    // every subject has 5000+ non-repeating question instances instead of just ~15. ----------

    private val TARGET_PER_SUBJECT = 1500

    private val gkDistractors = listOf(
        "Mumbai", "Chennai", "Kolkata", "Bangalore", "Hyderabad", "Pune", "Jaipur", "Lucknow",
        "Africa", "Europe", "Australia", "Antarctica", "5", "6", "9", "10",
        "Sparrow", "Crow", "Eagle", "Owl", "Amazon", "Nile", "Yamuna", "Godavari",
        "Lion", "Elephant", "Leopard", "Cheetah", "Monaco", "Malta", "Nauru",
        "Venus", "Jupiter", "Saturn", "K2", "Giraffe", "Shark", "Horse", "Tiger",
        "Mercury", "Mars", "Pluto", "Ostrich", "Parrot", "Thar", "Sahara", "Gobi", "Kalahari",
        "England", "France", "Spain", "Italy", "Camel", "Iron", "Gold", "Silver",
        "8", "12", "Peacock", "Holi", "Eid", "Christmas", "Starfish", "Octopus", "Jellyfish",
        "Crab", "Diamond", "Potato", "Onion", "Carrot", "Tomato", "20", "26", "7",
        "Niagara Falls", "Angel Falls", "Victoria Falls", "Jog Falls", "Greenland", "Madagascar",
        "Borneo", "Sumatra", "Earth", "Stapes", "Femur", "Radius", "Tibia", "USA", "China", "Russia",
        "Ganga", "Yangtze", "Mekong", "Indus", "90", "100", "110", "120", "Red Sea Reef",
        "Great Barrier Reef", "Belize Reef", "Coral Triangle", "Neptune", "Java Trench",
        "Mariana Trench", "Tonga Trench", "Peru Trench", "Donkey", "Peregrine Falcon", "Hawk",
        "-10", "0", "Lake Victoria", "Lake Superior", "Lake Baikal", "Lake Tanganyika", "Oxygen",
        "Nitrogen", "Hydrogen", "Norway", "Finland", "Sweden", "Iceland", "South America",
        "Whale", "Tortoise", "English", "Mandarin Chinese", "Spanish", "Hindi",
        "Egypt", "Greece", "Sunflower", "Rafflesia", "Lily", "Rose", "Siberia", "Alaska",
        "Football", "Cricket", "Hockey", "Tennis", "11", "Mexico", "Peru", "Antarctic Desert",
        "Lotus", "Marigold", "Ant", "Silkworm", "Bee", "Butterfly", "Japan", "Thailand", "Korea",
        "Frog", "Chameleon", "Lizard", "Snake", "JFK Airport", "Heathrow Airport",
        "Hartsfield-Jackson Atlanta", "Dubai Airport", "Indian Ocean", "Arctic Ocean",
        "Atlantic Ocean", "Pacific Ocean", "Vietnam", "Pigeon", "Burj Khalifa", "Shanghai Tower",
        "Eiffel Tower", "Empire State Building", "Cat", "Dog", "Cow", "Canada",
        "Great White Shark", "Whale Shark", "Hammerhead Shark", "Tiger Shark", "Atacama Desert",
        "Uranus", "Summer", "Spring", "Autumn", "Monsoon", "Mango", "Banyan", "Neem", "Peepal",
        "Otter", "Beaver", "Squirrel", "Rabbit", "Tokyo", "Delhi", "Shanghai"
    )
    private val sstDistractors = listOf(
        "Gandhi", "Bose", "Patel", "Nehru", "Delhi", "Mumbai", "Chennai", "Kolkata", "Agra",
        "Jaipur", "China", "Japan", "Korea", "1945", "1946", "1950", "Godavari", "Krishna",
        "Yamuna", "Rabindranath Tagore", "Sarojini Naidu", "Iqbal", "Goa", "Tripura", "Kerala",
        "27", "29", "31", "Akbar", "Babur", "Aurangzeb", "Dollar", "Dinar", "Yen", "Nagpur", "Nashik",
        "Ahmedabad", "Surat", "Gandhinagar", "Vadodara", "Quit India", "Non-Cooperation", "Swadeshi",
        "Padma Shri", "Padma Bhushan", "Ashoka Chakra", "Egyptian", "Roman", "Greek",
        "Jodhpur", "Udaipur", "Jaisalmer", "Red Fort", "Taj Mahal", "Qutub Minar",
        "Africa", "Europe", "Australia", "Bhagat Singh", "Tilak", "Gujarat", "Tamil Nadu",
        "Kutch", "Rajasthan Desert", "Sahara", "Karnataka", "Nanda Devi", "Kangchenjunga", "K2",
        "Everest", "Humayun", "Jahangir", "Bangalore", "Pune", "Vedic", "Maurya", "Gupta",
        "Battle of Panipat", "Battle of Buxar", "Battle of Haldighati", "Asia", "Indus",
        "Mysore", "Hubli", "Mangalore", "Mauryas", "Chandelas", "Guptas", "Cholas",
        "Islam", "Christianity", "Hinduism", "Buddhism", "South America", "Assam", "Sikkim",
        "Ludhiana", "Amritsar", "Chandigarh", "Patiala", "Maharashtra", "Punjab", "Pakistan",
        "Bangladesh", "Nepal", "USA", "Indonesia", "Bankim Chandra Chatterjee",
        "Bhopal", "Srinagar", "Mizoram", "Haryana", "B.R. Ambedkar"
    )
    private val biologyDistractors = listOf(
        "Root", "Stem", "Flower", "196", "216", "226", "Lungs", "Kidney", "Liver",
        "Carbon Dioxide", "Nitrogen", "Hydrogen", "Carnivores", "Omnivores", "Insectivores",
        "Skin", "Brain", "2", "3", "5", "Red blood cells", "Platelets", "Plasma",
        "Respiration", "Digestion", "Excretion", "Tissue", "Organ", "Molecule", "Stomach",
        "Vitamin A", "Vitamin C", "Vitamin K", "Cat", "Horse", "Cow", "Cub", "Calf", "Kitten",
        "Ear", "Nose", "Nucleus", "Cytoplasm", "Membrane", "Vitamin B", "Vitamin D",
        "Kangaroo", "Dolphin", "Bat", "Pancreas", "Thyroid", "Pituitary", "Heart",
        "Oxygen", "Physics", "Chemistry", "Geology", "Retina", "Lens", "Cornea",
        "A", "B", "AB", "O negative", "Femur", "Humerus", "Tibia", "Fibula",
        "Eye", "Tongue", "10", "12", "14", "16", "Cell", "Organism", "Mammals", "Amphibians",
        "Reptiles", "Birds", "Cerebrum", "Cerebellum", "Medulla", "Hypothalamus", "Vitamin E",
        "Patella", "Herbivores", "Dermis", "Epidermis", "Hypodermis", "Cortex", "Transpiration",
        "Snake", "Dog", "Fruit", "Molars", "Incisors", "Canines", "Premolars", "28", "30", "32", "34"
    )
    private val reasoningDistractors = listOf(
        "4", "6", "8", "9", "18", "20", "22", "24", "25", "30", "5",
        "B", "C", "D", "F", "H", "I", "J", "K",
        "Dog", "Cat", "Car", "Cow", "Tuesday", "Wednesday", "Thursday", "Friday", "Sunday",
        "Saturday", "Monday", "Cannot say", "Both equal", "Circle", "Square", "Pentagon",
        "27", "40", "81", "EPH", "EPI", "FPH", "EQH", "36", "48", "42",
        "60", "90", "120", "180", "Apple", "Banana", "Potato", "Mango",
        "26", "28", "S", "R", "Q", "P", "102", "210", "610",
        "Triangle", "Red", "Brother", "Sister", "Mother", "Aunt",
        "11", "12", "13", "14", "16", "49", "North", "South", "West", "East",
        "Rose", "Lily", "Lotus", "50", "55", "65", "Run", "Walk", "Jump", "Table",
        "L", "32", "34", "Animal", "Plant", "Bird", "Feathers", "Stones", "Rectangle"
    )
    private val computerDistractors = listOf(
        "Monitor", "Printer", "Speaker", "Scanner", "Compiler", "Editor", "Player",
        "Delete", "Enter", "Shift", "Meters", "Litres", "Kilograms",
        "World Wide Wire", "Web Wide World", "Wide World Web", "Keyboard", "Mouse", "CPU",
        "Read Access Memory", "Random Active Memory", "Read Active Memory",
        "Calculator", "Browser", "Antivirus", "Windows", "Word", "Excel",
        "HTML", "Photoshop", "Ctrl+V", "Ctrl+X", "Ctrl+Z", "Router",
        "United Serial Bus", "Universal System Bus", "United System Bus",
        "Downloads", "Documents", "Desktop", "Linux", "MS Word",
        "Personal Document File", "Printed Document Format", "Public Data File",
        "Apple", "Google", "IBM", "#", "&", "%", "Server", "Hub",
        "World Wide Web", "World Web Wide", "CAM", "TAM", "FAM",
        "Samsung", "Sony", "RAM", ".doc", ".mp3", ".exe", "Android", "Chrome", "Facebook",
        "Tab", "Ctrl", "Draft", "Inbox", "Sent", "Microsoft", "Alphabet", "Amazon",
        "Automatic Transfer Machine", "Auto Task Machine", "Advanced Teller Machine"
    )
    private val englishDistractors = listOf(
        "Recieve", "Receeve", "Receve", "Childs", "Childes", "Childrens", "Sad", "Angry",
        "Tired", "Run", "Beautiful", "Quickly", "go", "going", "gone", "Large", "Huge", "Tall",
        "Table", "Blue", "Happy", "He go to school", "He going school", "He gone school",
        "Warm", "Sunny", "Bright", "A", "The", "No article", "Slow", "Lazy", "Heavy", "Jump",
        "Goed", "Gone", "Going", "whats your name", "whats your name?", "What's your name",
        "She", "Hard", "Tough", "Complex", "Mouses", "Mouse", "Meece",
        "She don't like it", "She doesn't likes it", "She not like it",
        "Gooder", "Best", "More good", "Definately", "Definitly", "Definetly",
        "in", "at", "by", "Bigger", "More big", "Most big", "city", "river", "book",
        "I is happy", "I be happy", "I are happy", "Tooths", "Teeths", "Toothes",
        "Over", "Up", "High", "Neccessary", "Neccesary", "Necesary", "And",
        "Eated", "Eaten", "Eating", "An", "Wow!", "Mans", "Manes", "Mens",
        "He can sings well", "He can singing well", "He cans sing well",
        "Dog", "Cup", "Pen", "Leafs", "Leafes"
    )
    private val hindiDistractors = listOf(
        "कलम", "मेज़", "कुर्सी", "लंबा", "ऊँचा", "मोटा", "राम", "खाना", "है",
        "10", "11", "13", "चाँद", "तारा", "बादल", "दिन", "सुबह", "शाम", "दोपहर",
        "खट्टा", "कड़वा", "नमकीन", "तीखा", "पुल्लिंग", "नपुंसक", "कोई नहीं",
        "अग्नि", "वायु", "मिट्टी", "30", "35", "40", "छोटा",
        "फूलें", "फूला", "वह", "इनमें से कोई नहीं", "अच्छा", "प्यारा", "सुशील",
        "अश्व", "सिंह", "व्याघ्र", "धनी", "सुखी", "समृद्ध", "पर्वत", "नदी", "मैदान",
        "2", "3", "5", "6", "कान", "नाक", "मुँह", "तेज़", "फुर्ती", "शीघ्र",
        "बहन", "बेटी", "पत्नी", "रोमन", "उर्दू", "गुरुमुखी", "ईमानदारी", "न्याय", "धर्म",
        "धरती", "सागर", "पाताल", "मुश्किल", "जटिल", "उलझा", "4", "पुत्र", "भाई", "मामा",
        "आगे", "पीछे", "बगल", "रेगिस्तान", "समुद्र"
    )

    private val distractorBanks: Map<Subject, List<String>> = mapOf(
        Subject.GK to gkDistractors,
        Subject.SST to sstDistractors,
        Subject.BIOLOGY to biologyDistractors,
        Subject.REASONING to reasoningDistractors,
        Subject.COMPUTER to computerDistractors,
        Subject.ENGLISH to englishDistractors,
        Subject.HINDI to hindiDistractors
    )

    /**
     * Expands a small curated fact list into MANY question INSTANCES by combining each
     * fact's correct answer with different random 3-distractor picks from the subject's
     * bank. This uses lightweight random sampling (a few dozen picks per fact) instead of
     * pre-computing every possible combination - with banks now 80-200 items large,
     * enumerating all combinations upfront (up to 1.2 MILLION for GK alone) is what was
     * freezing the screen on first open. Random sampling only does as much work as the
     * actual target count needs, so it stays fast regardless of bank size.
     */
    private fun expandWithDistractors(facts: List<Question>, bank: List<String>, targetCount: Int): List<Question> {
        if (facts.isEmpty() || bank.size < 4) return facts
        val perFact = (targetCount / facts.size) + 1
        val result = ArrayList<Question>(targetCount)

        for (fact in facts) {
            val correct = fact.options[fact.correctIndex]
            val candidateBank = bank.filter { it != correct }
            val rnd = Random(fact.question.hashCode().toLong())
            val seen = HashSet<List<String>>()
            var attempts = 0
            var generated = 0
            // With a bank much larger than what's needed per fact, collisions are rare,
            // so this loop almost always finishes in well under `perFact` iterations.
            while (generated < perFact && attempts < perFact * 3) {
                attempts++
                if (candidateBank.size < 3) break
                val i = rnd.nextInt(candidateBank.size)
                var j = rnd.nextInt(candidateBank.size)
                while (j == i) j = rnd.nextInt(candidateBank.size)
                var k = rnd.nextInt(candidateBank.size)
                while (k == i || k == j) k = rnd.nextInt(candidateBank.size)
                val distractors = listOf(candidateBank[i], candidateBank[j], candidateBank[k]).sorted()
                if (!seen.add(distractors)) continue
                val options = (distractors + correct).shuffled(rnd)
                result.add(Question(fact.question, options, options.indexOf(correct)))
                generated++
            }
        }
        return result
    }

    /** Remix mixes every other subject's EXPANDED pool into one huge shuffled bag. */
    private val remixPool: List<Question> by lazy {
        Subject.values()
            .filter { it != Subject.MATH && it != Subject.REMIX }
            .flatMap { expandedPoolFor(it) }
    }

    private val expandedPoolCache = HashMap<Subject, List<Question>>()

    private fun expandedPoolFor(subject: Subject): List<Question> {
        expandedPoolCache[subject]?.let { return it }
        val facts = poolsBySubject[subject] ?: return emptyList()
        val bank = distractorBanks[subject] ?: return facts
        val expanded = expandWithDistractors(facts, bank, TARGET_PER_SUBJECT)
        expandedPoolCache[subject] = expanded
        return expanded
    }

    fun poolFor(subject: Subject): List<Question> = when (subject) {
        Subject.REMIX -> remixPool
        Subject.MATH -> emptyList() // handled procedurally, not via pool
        else -> expandedPoolFor(subject)
    }
}
