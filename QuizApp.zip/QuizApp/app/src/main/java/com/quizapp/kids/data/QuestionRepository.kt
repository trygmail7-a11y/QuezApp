package com.quizapp.kids.data

import android.content.Context
import com.google.gson.Gson
import kotlin.random.Random

/**
 * Loads questions for a given Subject + Class + Language + Level.
 *
 * Priority:
 * 1) Hand-written questions from assets/questions/{subject}/class{N}_{lang}.json
 *    (best quality — add as many levels as you want, see README for format).
 * 2) If that level isn't present yet, a fallback question set is generated
 *    automatically so ALL 1000 levels x 8 subjects x 10 classes always work
 *    out of the box. Replace these gradually with real JSON content.
 */
class QuestionRepository(private val context: Context) {

    private val gson = Gson()
    private val cache = HashMap<String, ClassQuestionBank?>()

    private fun loadBank(subject: Subject, classId: Int, language: String): ClassQuestionBank? {
        val key = "${subject.id}_${classId}_$language"
        if (cache.containsKey(key)) return cache[key]
        val bank = try {
            val fileName = "questions/${subject.id}/class${classId}_${language}.json"
            val json = context.assets.open(fileName).bufferedReader().use { it.readText() }
            gson.fromJson(json, ClassQuestionBank::class.java)
        } catch (e: Exception) {
            null
        }
        cache[key] = bank
        return bank
    }

    fun getLevel(subject: Subject, classId: Int, language: String, level: Int): LevelData {
        val bank = loadBank(subject, classId, language)
        val handWritten = bank?.levels?.find { it.level == level }
        if (handWritten != null && handWritten.questions.isNotEmpty()) return handWritten
        return FallbackQuestionGenerator.generate(subject, classId, level)
    }
}

/**
 * Generates a question set so every level always has content, even before real
 * questions are authored. Math gets real arithmetic scaled by class+level.
 * Other subjects cycle through a small curated sample pool (add real JSON content
 * per subject to replace these).
 */
object FallbackQuestionGenerator {

    fun generate(subject: Subject, classId: Int, level: Int): LevelData {
        val questions = if (subject == Subject.MATH) {
            generateMathQuestions(classId, level)
        } else {
            generateSampleBankQuestions(subject, classId, level)
        }
        return LevelData(level = level, questions = questions)
    }

    private fun generateMathQuestions(classId: Int, level: Int): List<Question> {
        val seed = classId * 100000L + level
        val rnd = Random(seed)
        val maxNumber = (10 + classId * 8 + level / 4).coerceAtMost(9999)
        return (1..5).map { generateMathQuestion(rnd, maxNumber) }
    }

    private fun generateMathQuestion(rnd: Random, maxNumber: Int): Question {
        val a = rnd.nextInt(1, maxNumber)
        val b = rnd.nextInt(1, maxNumber)
        val opPick = rnd.nextInt(0, 3)
        val (text, correct) = when (opPick) {
            0 -> "$a + $b = ?" to (a + b)
            1 -> {
                val big = maxOf(a, b); val small = minOf(a, b)
                "$big - $small = ?" to (big - small)
            }
            else -> {
                val s1 = rnd.nextInt(1, 12); val s2 = rnd.nextInt(1, 12)
                "$s1 x $s2 = ?" to (s1 * s2)
            }
        }
        val options = mutableListOf(correct)
        while (options.size < 4) {
            val delta = rnd.nextInt(-5, 6)
            val candidate = correct + delta + if (delta == 0) rnd.nextInt(1, 4) else 0
            if (candidate >= 0 && !options.contains(candidate)) options.add(candidate)
        }
        options.shuffle(rnd)
        return Question(
            question = text,
            options = options.map { it.toString() },
            correctIndex = options.indexOf(correct)
        )
    }

    // Small curated sample pools per subject, cycled by level so the app always has
    // something reasonable to show. Replace with real per-level JSON content over time.
    private val samplePools: Map<Subject, List<Question>> = mapOf(
        Subject.GK to listOf(
            Question("What is the capital of India?", listOf("Mumbai", "Delhi", "Chennai", "Kolkata"), 1),
            Question("Which is the largest continent?", listOf("Africa", "Asia", "Europe", "Australia"), 1),
            Question("How many planets are in our solar system?", listOf("7", "8", "9", "10"), 1),
            Question("Which is the national bird of India?", listOf("Sparrow", "Peacock", "Crow", "Eagle"), 1),
            Question("Which river is the longest in the world?", listOf("Ganga", "Amazon", "Nile", "Yamuna"), 2)
        ),
        Subject.SST to listOf(
            Question("Who was the first Prime Minister of India?", listOf("Gandhi", "Nehru", "Patel", "Bose"), 1),
            Question("In which year did India get independence?", listOf("1945", "1946", "1947", "1950"), 2),
            Question("Which is the largest state in India by area?", listOf("Rajasthan", "UP", "MP", "Maharashtra"), 0),
            Question("The Taj Mahal is located in which city?", listOf("Delhi", "Agra", "Jaipur", "Lucknow"), 1),
            Question("Which ocean is to the west of India?", listOf("Pacific", "Atlantic", "Arabian Sea", "Indian Ocean"), 2)
        ),
        Subject.BIOLOGY to listOf(
            Question("Which part of the plant makes food?", listOf("Root", "Stem", "Leaf", "Flower"), 2),
            Question("How many bones are in an adult human body?", listOf("196", "206", "216", "226"), 1),
            Question("Which organ pumps blood in our body?", listOf("Lungs", "Heart", "Kidney", "Liver"), 1),
            Question("Which gas do plants release during the day?", listOf("Carbon Dioxide", "Oxygen", "Nitrogen", "Hydrogen"), 1),
            Question("What do we call animals that eat only plants?", listOf("Carnivores", "Herbivores", "Omnivores", "Insectivores"), 1)
        ),
        Subject.REASONING to listOf(
            Question("Find the odd one out: 2, 4, 6, 9, 8", listOf("4", "9", "6", "8"), 1),
            Question("If A=1, B=2, C=3... what is E?", listOf("4", "5", "6", "7"), 1),
            Question("Complete: 2, 4, 8, 16, ?", listOf("18", "24", "32", "20"), 2),
            Question("Which shape has 3 sides?", listOf("Square", "Triangle", "Circle", "Pentagon"), 1),
            Question("Monday, Tuesday, Wednesday, ?", listOf("Friday", "Sunday", "Thursday", "Saturday"), 2)
        ),
        Subject.COMPUTER to listOf(
            Question("What does CPU stand for?", listOf("Central Process Unit", "Central Processing Unit", "Computer Personal Unit", "Central Processor Unit"), 1),
            Question("Which of these is an input device?", listOf("Monitor", "Printer", "Keyboard", "Speaker"), 2),
            Question("What do we use to open a website?", listOf("Browser", "Compiler", "Editor", "Player"), 0),
            Question("Which key deletes a character to the left?", listOf("Delete", "Backspace", "Enter", "Shift"), 1),
            Question("A computer's memory is measured in?", listOf("Meters", "Bytes", "Litres", "Kilograms"), 1)
        ),
        Subject.ENGLISH to listOf(
            Question("Choose the correct spelling.", listOf("Recieve", "Receive", "Receeve", "Receve"), 1),
            Question("What is the plural of 'Child'?", listOf("Childs", "Childes", "Children", "Childrens"), 2),
            Question("Choose the synonym of 'Happy'.", listOf("Sad", "Angry", "Joyful", "Tired"), 2),
            Question("Which word is a noun?", listOf("Run", "Beautiful", "Table", "Quickly"), 2),
            Question("Fill in the blank: She ___ to school every day.", listOf("go", "goes", "going", "gone"), 1)
        ),
        Subject.HINDI to listOf(
            Question("'पुस्तक' का पर्यायवाची शब्द चुनें।", listOf("किताब", "कलम", "मेज़", "कुर्सी"), 0),
            Question("'बड़ा' का विलोम शब्द क्या है?", listOf("लंबा", "छोटा", "ऊँचा", "मोटा"), 1),
            Question("'राम खाना खाता है' — इसमें क्रिया कौन सी है?", listOf("राम", "खाना", "खाता है", "है"), 2),
            Question("हिंदी वर्णमाला में कितने स्वर होते हैं?", listOf("10", "11", "12", "13"), 1),
            Question("'सूर्य' का पर्यायवाची क्या है?", listOf("चाँद", "तारा", "रवि", "बादल"), 2)
        )
    )

    private fun generateSampleBankQuestions(subject: Subject, classId: Int, level: Int): List<Question> {
        val pool = samplePools[subject] ?: return generateMathQuestions(classId, level)
        // Cycle through the sample pool deterministically per level so it stays varied.
        val rnd = Random(subject.id.hashCode() * 31L + classId * 100000L + level)
        return pool.shuffled(rnd).take(5).let { if (it.size < 5) it + pool.take(5 - it.size) else it }
    }
}
