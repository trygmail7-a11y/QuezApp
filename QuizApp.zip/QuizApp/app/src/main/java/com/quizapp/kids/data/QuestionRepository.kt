package com.quizapp.kids.data

import android.content.Context
import com.google.gson.Gson
import java.security.MessageDigest
import kotlin.random.Random

/**
 * Loads questions for a given Subject + Class + Language + Level.
 *
 * Priority:
 * 1) A level that was already played before ALWAYS returns the same cached question
 *    set (so retrying a level shows the same questions again, as expected).
 * 2) Hand-written questions from assets/questions/{subject}/class{N}_{lang}.json
 *    (best quality — add as many levels as you want, see README for format).
 * 3) Otherwise, a fresh set is picked from a subject question pool WITHOUT repeating
 *    any question the child has already seen in that subject — until the whole pool
 *    has been used once, at which point it cycles again. Math questions are generated
 *    procedurally so they are naturally varied level to level.
 */
class QuestionRepository(private val context: Context, private val profileManager: ProfileManager) {

    private val gson = Gson()
    private val cache = HashMap<String, ClassQuestionBank?>()

    private fun loadBank(subject: Subject, classId: Int, language: String): ClassQuestionBank? {
        val key = "${subject.id}_${classId}_$language"
        if (cache.containsKey(key)) return cache[key]
        val bank = try {
            val fileName = "questions/${subject.id}/class${classId}_${language}.json"
            val json = context.assets.open(fileName).bufferedReader().use { it.readText() }
            gson.fromJson(json, ClassQuestionBank::class.java)
        } catch (e: Exception) {
            null
        }
        cache[key] = bank
        return bank
    }

    fun getLevel(subject: Subject, classId: Int, language: String, level: Int, profileName: String): LevelData {
        // 1) Already played this exact level before? Always return the same set (retry consistency).
        profileManager.getCachedLevelQuestions(profileName, subject, classId, language, level)?.let {
            return LevelData(level, it)
        }

        // 2) Hand-written content for this level, if present.
        val bank = loadBank(subject, classId, language)
        val handWritten = bank?.levels?.find { it.level == level }
        if (handWritten != null && handWritten.questions.isNotEmpty()) {
            profileManager.saveCachedLevelQuestions(profileName, subject, classId, language, level, handWritten.questions)
            return handWritten
        }

        // 3) Freshly picked, non-repeating (until pool exhausted) fallback content.
        val questions = if (subject == Subject.MATH) {
            FallbackQuestionGenerator.generateMathQuestions(classId, level)
        } else {
            pickNonRepeatingQuestions(subject, classId, language, level, profileName)
        }
        profileManager.saveCachedLevelQuestions(profileName, subject, classId, language, level, questions)
        return LevelData(level, questions)
    }

    private fun questionHash(q: Question): String {
        val raw = q.question + "|" + q.options.joinToString(",")
        val digest = MessageDigest.getInstance("MD5").digest(raw.toByteArray())
        return digest.joinToString("") { "%02x".format(it) }
    }

    private fun pickNonRepeatingQuestions(
        subject: Subject,
        classId: Int,
        language: String,
        level: Int,
        profileName: String
    ): List<Question> {
        val fullPool = FallbackQuestionGenerator.poolFor(subject)
        if (fullPool.isEmpty()) return FallbackQuestionGenerator.generateMathQuestions(classId, level)

        val used = profileManager.getUsedQuestionHashes(profileName, subject, classId, language)
        var remaining = fullPool.filter { questionHash(it) !in used }

        // Pool exhausted - everything has been seen at least once, so start a fresh cycle.
        if (remaining.size < QUESTIONS_PER_LEVEL) {
            profileManager.resetUsedQuestionHashes(profileName, subject, classId, language)
            remaining = fullPool
        }

        val rnd = Random(subject.id.hashCode() * 31L + classId * 100000L + level)
        val picked = remaining.shuffled(rnd).take(QUESTIONS_PER_LEVEL)
        val finalPicked = if (picked.size < QUESTIONS_PER_LEVEL) {
            (picked + fullPool.shuffled(rnd)).distinct().take(QUESTIONS_PER_LEVEL)
        } else picked

        profileManager.markQuestionHashesUsed(profileName, subject, classId, language, finalPicked.map { questionHash(it) })
        return finalPicked
    }

    companion object {
        private const val QUESTIONS_PER_LEVEL = ProfileManager.QUESTIONS_PER_LEVEL
    }
}

/**
 * Curated sample question pools + procedural math generation, used as fallback content
 * so every level always has something to show before real per-level JSON is authored.
 */
object FallbackQuestionGenerator {

    fun generateMathQuestions(classId: Int, level: Int): List<Question> {
        val seed = classId * 100000L + level
        val rnd = Random(seed)
        val maxNumber = (10 + classId * 8 + level / 4).coerceAtMost(9999)
        return (1..5).map { generateMathQuestion(rnd, maxNumber) }
    }

    private fun generateMathQuestion(rnd: Random, maxNumber: Int): Question {
        val a = rnd.nextInt(1, maxNumber)
        val b = rnd.nextInt(1, maxNumber)
        val opPick = rnd.nextInt(0, 3)
        val (text, correct) = when (opPick) {
            0 -> "$a + $b = ?" to (a + b)
            1 -> {
                val big = maxOf(a, b); val small = minOf(a, b)
                "$big - $small = ?" to (big - small)
            }
            else -> {
                val s1 = rnd.nextInt(1, 12); val s2 = rnd.nextInt(1, 12)
                "$s1 x $s2 = ?" to (s1 * s2)
            }
        }
        val options = mutableListOf(correct)
        while (options.size < 4) {
            val delta = rnd.nextInt(-5, 6)
            val candidate = correct + delta + if (delta == 0) rnd.nextInt(1, 4) else 0
            if (candidate >= 0 && !options.contains(candidate)) options.add(candidate)
        }
        options.shuffle(rnd)
        return Question(
            question = text,
            options = options.map { it.toString() },
            correctIndex = options.indexOf(correct)
        )
    }

    val gkPool = listOf(
        Question("What is the capital of India?", listOf("Mumbai", "Delhi", "Chennai", "Kolkata"), 1),
        Question("Which is the largest continent?", listOf("Africa", "Asia", "Europe", "Australia"), 1),
        Question("How many planets are in our solar system?", listOf("7", "8", "9", "10"), 1),
        Question("Which is the national bird of India?", listOf("Sparrow", "Peacock", "Crow", "Eagle"), 1),
        Question("Which river is the longest in the world?", listOf("Ganga", "Amazon", "Nile", "Yamuna"), 2),
        Question("Which is the national animal of India?", listOf("Lion", "Tiger", "Elephant", "Leopard"), 1),
        Question("Which is the smallest country in the world?", listOf("Monaco", "Vatican City", "Malta", "Nauru"), 1),
        Question("Which planet is known as the Red Planet?", listOf("Venus", "Mars", "Jupiter", "Saturn"), 1),
        Question("Which is the tallest mountain in the world?", listOf("K2", "Everest", "Kangchenjunga", "Makalu"), 1),
        Question("Which gas do humans need to breathe?", listOf("Carbon Dioxide", "Oxygen", "Nitrogen", "Hydrogen"), 1),
        Question("How many continents are there?", listOf("5", "6", "7", "8"), 2),
        Question("Which is the largest ocean?", listOf("Atlantic", "Indian", "Pacific", "Arctic"), 2),
        Question("Which country is known as the Land of the Rising Sun?", listOf("China", "Japan", "Korea", "Thailand"), 1),
        Question("What is the national sport of India?", listOf("Cricket", "Football", "Hockey", "Kabaddi"), 2),
        Question("Which fruit is known as the King of Fruits?", listOf("Apple", "Banana", "Mango", "Grapes"), 2),
        Question("Which is the fastest land animal?", listOf("Lion", "Cheetah", "Horse", "Tiger"), 1),
        Question("Which day is celebrated as Independence Day in India?", listOf("15 August", "26 January", "2 October", "14 November"), 0),
        Question("Which is the largest mammal in the world?", listOf("Elephant", "Blue Whale", "Giraffe", "Shark"), 1)
    )

    val sstPool = listOf(
        Question("Who was the first Prime Minister of India?", listOf("Gandhi", "Nehru", "Patel", "Bose"), 1),
        Question("In which year did India get independence?", listOf("1945", "1946", "1947", "1950"), 2),
        Question("Which is the largest state in India by area?", listOf("Rajasthan", "UP", "MP", "Maharashtra"), 0),
        Question("The Taj Mahal is located in which city?", listOf("Delhi", "Agra", "Jaipur", "Lucknow"), 1),
        Question("Which ocean is to the west of India?", listOf("Pacific", "Atlantic", "Arabian Sea", "Indian Ocean"), 2),
        Question("Who is known as the Father of the Nation in India?", listOf("Nehru", "Gandhi", "Bose", "Patel"), 1),
        Question("Which is the capital of Maharashtra?", listOf("Pune", "Nagpur", "Mumbai", "Nashik"), 2),
        Question("The Great Wall is located in which country?", listOf("Japan", "China", "India", "Korea"), 1),
        Question("Which is the longest river in India?", listOf("Yamuna", "Ganga", "Godavari", "Krishna"), 1),
        Question("Who wrote the Indian National Anthem?", listOf("Bankim Chandra", "Rabindranath Tagore", "Sarojini Naidu", "Iqbal"), 1),
        Question("Which is the smallest state in India by area?", listOf("Goa", "Sikkim", "Tripura", "Kerala"), 0),
        Question("How many states are there in India?", listOf("27", "28", "29", "31"), 1),
        Question("Which Mughal emperor built the Taj Mahal?", listOf("Akbar", "Shah Jahan", "Babur", "Aurangzeb"), 1),
        Question("Which is the currency of India?", listOf("Dollar", "Rupee", "Dinar", "Yen"), 1),
        Question("Who was the first President of India?", listOf("Nehru", "Rajendra Prasad", "Gandhi", "Patel"), 1)
    )

    val biologyPool = listOf(
        Question("Which part of the plant makes food?", listOf("Root", "Stem", "Leaf", "Flower"), 2),
        Question("How many bones are in an adult human body?", listOf("196", "206", "216", "226"), 1),
        Question("Which organ pumps blood in our body?", listOf("Lungs", "Heart", "Kidney", "Liver"), 1),
        Question("Which gas do plants release during the day?", listOf("Carbon Dioxide", "Oxygen", "Nitrogen", "Hydrogen"), 1),
        Question("What do we call animals that eat only plants?", listOf("Carnivores", "Herbivores", "Omnivores", "Insectivores"), 1),
        Question("Which is the largest organ in the human body?", listOf("Liver", "Skin", "Heart", "Brain"), 1),
        Question("How many chambers does the human heart have?", listOf("2", "3", "4", "5"), 2),
        Question("Which blood cells fight infections?", listOf("Red blood cells", "White blood cells", "Platelets", "Plasma"), 1),
        Question("Which process do plants use to make food?", listOf("Respiration", "Photosynthesis", "Digestion", "Excretion"), 1),
        Question("What is the basic unit of life?", listOf("Tissue", "Organ", "Cell", "Molecule"), 2),
        Question("Which organ helps us breathe?", listOf("Heart", "Lungs", "Stomach", "Kidney"), 1),
        Question("Which vitamin do we get from sunlight?", listOf("Vitamin A", "Vitamin C", "Vitamin D", "Vitamin K"), 2),
        Question("Which animal is known as man's best friend?", listOf("Cat", "Dog", "Horse", "Cow"), 1),
        Question("What do we call baby frogs?", listOf("Cub", "Tadpole", "Calf", "Kitten"), 1)
    )

    val reasoningPool = listOf(
        Question("Find the odd one out: 2, 4, 6, 9, 8", listOf("4", "9", "6", "8"), 1),
        Question("If A=1, B=2, C=3... what is E?", listOf("4", "5", "6", "7"), 1),
        Question("Complete: 2, 4, 8, 16, ?", listOf("18", "24", "32", "20"), 2),
        Question("Which shape has 3 sides?", listOf("Square", "Triangle", "Circle", "Pentagon"), 1),
        Question("Monday, Tuesday, Wednesday, ?", listOf("Friday", "Sunday", "Thursday", "Saturday"), 2),
        Question("Complete the series: 1, 4, 9, 16, ?", listOf("20", "25", "24", "22"), 1),
        Question("Which number comes next: 5, 10, 15, 20, ?", listOf("22", "25", "24", "30"), 1),
        Question("Find the odd one: Dog, Cat, Car, Cow", listOf("Dog", "Cat", "Car", "Cow"), 2),
        Question("If today is Monday, what day is after tomorrow?", listOf("Tuesday", "Wednesday", "Thursday", "Friday"), 1),
        Question("Which is heavier: 1 kg cotton or 1 kg iron?", listOf("Cotton", "Iron", "Both equal", "Cannot say"), 2),
        Question("Find the odd one out: Circle, Square, Triangle, Red", listOf("Circle", "Square", "Triangle", "Red"), 3),
        Question("Complete: A, C, E, G, ?", listOf("H", "I", "J", "K"), 1)
    )

    val computerPool = listOf(
        Question("What does CPU stand for?", listOf("Central Process Unit", "Central Processing Unit", "Computer Personal Unit", "Central Processor Unit"), 1),
        Question("Which of these is an input device?", listOf("Monitor", "Printer", "Keyboard", "Speaker"), 2),
        Question("What do we use to open a website?", listOf("Browser", "Compiler", "Editor", "Player"), 0),
        Question("Which key deletes a character to the left?", listOf("Delete", "Backspace", "Enter", "Shift"), 1),
        Question("A computer's memory is measured in?", listOf("Meters", "Bytes", "Litres", "Kilograms"), 1),
        Question("Which of these is an output device?", listOf("Keyboard", "Mouse", "Monitor", "Scanner"), 2),
        Question("What does WWW stand for?", listOf("World Wide Web", "World Wide Wire", "Web Wide World", "Wide World Web"), 0),
        Question("Which device is used to point and click?", listOf("Keyboard", "Mouse", "Monitor", "CPU"), 1),
        Question("What is the full form of RAM?", listOf("Random Access Memory", "Read Access Memory", "Random Active Memory", "Read Active Memory"), 0),
        Question("Which software helps us type documents?", listOf("Calculator", "Word Processor", "Browser", "Antivirus"), 1),
        Question("Which of these is a search engine?", listOf("Google", "Windows", "Word", "Excel"), 0),
        Question("What is used to save your work permanently?", listOf("RAM", "Save/Storage", "CPU", "Monitor"), 1)
    )

    val englishPool = listOf(
        Question("Choose the correct spelling.", listOf("Recieve", "Receive", "Receeve", "Receve"), 1),
        Question("What is the plural of 'Child'?", listOf("Childs", "Childes", "Children", "Childrens"), 2),
        Question("Choose the synonym of 'Happy'.", listOf("Sad", "Angry", "Joyful", "Tired"), 2),
        Question("Which word is a noun?", listOf("Run", "Beautiful", "Table", "Quickly"), 2),
        Question("Fill in the blank: She ___ to school every day.", listOf("go", "goes", "going", "gone"), 1),
        Question("Choose the antonym of 'Big'.", listOf("Large", "Huge", "Small", "Tall"), 2),
        Question("Which is a verb?", listOf("Jump", "Table", "Blue", "Happy"), 0),
        Question("Which sentence is correct?", listOf("He go to school", "He goes to school", "He going school", "He gone school"), 1),
        Question("What is the opposite of 'Hot'?", listOf("Warm", "Cold", "Sunny", "Bright"), 1),
        Question("Choose the correct article: ___ apple", listOf("A", "An", "The", "No article"), 1),
        Question("Which word means the same as 'Fast'?", listOf("Slow", "Quick", "Lazy", "Heavy"), 1),
        Question("Which of these is an adjective?", listOf("Run", "Beautiful", "Quickly", "Table"), 1)
    )

    val hindiPool = listOf(
        Question("'पुस्तक' का पर्यायवाची शब्द चुनें।", listOf("किताब", "कलम", "मेज़", "कुर्सी"), 0),
        Question("'बड़ा' का विलोम शब्द क्या है?", listOf("लंबा", "छोटा", "ऊँचा", "मोटा"), 1),
        Question("'राम खाना खाता है' — इसमें क्रिया कौन सी है?", listOf("राम", "खाना", "खाता है", "है"), 2),
        Question("हिंदी वर्णमाला में कितने स्वर होते हैं?", listOf("10", "11", "12", "13"), 1),
        Question("'सूर्य' का पर्यायवाची क्या है?", listOf("चाँद", "तारा", "रवि", "बादल"), 2),
        Question("'रात' का विलोम शब्द क्या है?", listOf("दिन", "सुबह", "शाम", "दोपहर"), 0),
        Question("'मीठा' का विलोम शब्द है?", listOf("खट्टा", "कड़वा", "नमकीन", "तीखा"), 1),
        Question("'गाय' शब्द किस लिंग का है?", listOf("पुल्लिंग", "स्त्रीलिंग", "नपुंसक", "कोई नहीं"), 1),
        Question("'पानी' का पर्यायवाची शब्द है?", listOf("जल", "अग्नि", "वायु", "मिट्टी"), 0),
        Question("हिंदी में कुल कितने व्यंजन होते हैं?", listOf("30", "33", "35", "40"), 1)
    )

    private val poolsBySubject: Map<Subject, List<Question>> = mapOf(
        Subject.GK to gkPool,
        Subject.SST to sstPool,
        Subject.BIOLOGY to biologyPool,
        Subject.REASONING to reasoningPool,
        Subject.COMPUTER to computerPool,
        Subject.ENGLISH to englishPool,
        Subject.HINDI to hindiPool
    )

    // ---------- Distractor banks: shared wrong-answer options per subject, used to
    // combinatorially expand each curated question into MANY option-variants so that
    // every subject has 5000+ non-repeating question instances instead of just ~15. ----------

    private val TARGET_PER_SUBJECT = 5500

    private val gkDistractors = listOf(
        "Mumbai", "Chennai", "Kolkata", "Bangalore", "Hyderabad", "Pune", "Jaipur", "Lucknow",
        "Africa", "Europe", "Australia", "Antarctica", "5", "6", "9", "10",
        "Sparrow", "Crow", "Eagle", "Owl", "Amazon", "Nile", "Yamuna", "Godavari",
        "Lion", "Elephant", "Leopard", "Cheetah", "Monaco", "Malta", "Nauru",
        "Venus", "Jupiter", "Saturn", "K2", "Giraffe", "Shark", "Horse", "Tiger"
    )
    private val sstDistractors = listOf(
        "Gandhi", "Bose", "Patel", "Nehru", "Delhi", "Mumbai", "Chennai", "Kolkata", "Agra",
        "Jaipur", "China", "Japan", "Korea", "1945", "1946", "1950", "Godavari", "Krishna",
        "Yamuna", "Rabindranath Tagore", "Sarojini Naidu", "Iqbal", "Goa", "Tripura", "Kerala",
        "27", "29", "31", "Akbar", "Babur", "Aurangzeb", "Dollar", "Dinar", "Yen", "Nagpur", "Nashik"
    )
    private val biologyDistractors = listOf(
        "Root", "Stem", "Flower", "196", "216", "226", "Lungs", "Kidney", "Liver",
        "Carbon Dioxide", "Nitrogen", "Hydrogen", "Carnivores", "Omnivores", "Insectivores",
        "Skin", "Brain", "2", "3", "5", "Red blood cells", "Platelets", "Plasma",
        "Respiration", "Digestion", "Excretion", "Tissue", "Organ", "Molecule", "Stomach",
        "Vitamin A", "Vitamin C", "Vitamin K", "Cat", "Horse", "Cow", "Cub", "Calf", "Kitten"
    )
    private val reasoningDistractors = listOf(
        "4", "6", "8", "9", "18", "20", "22", "24", "25", "30", "5",
        "B", "C", "D", "F", "H", "I", "J", "K",
        "Dog", "Cat", "Car", "Cow", "Tuesday", "Wednesday", "Thursday", "Friday", "Sunday",
        "Saturday", "Cannot say", "Both equal", "Circle", "Square", "Pentagon"
    )
    private val computerDistractors = listOf(
        "Monitor", "Printer", "Speaker", "Scanner", "Compiler", "Editor", "Player",
        "Delete", "Enter", "Shift", "Meters", "Litres", "Kilograms",
        "World Wide Wire", "Web Wide World", "Wide World Web", "Keyboard", "Mouse", "CPU",
        "Read Access Memory", "Random Active Memory", "Read Active Memory",
        "Calculator", "Browser", "Antivirus", "Windows", "Word", "Excel"
    )
    private val englishDistractors = listOf(
        "Recieve", "Receeve", "Receve", "Childs", "Childes", "Childrens", "Sad", "Angry",
        "Tired", "Run", "Beautiful", "Quickly", "go", "going", "gone", "Large", "Huge", "Tall",
        "Table", "Blue", "Happy", "He go to school", "He going school", "He gone school",
        "Warm", "Sunny", "Bright", "A", "The", "No article", "Slow", "Lazy", "Heavy", "Jump"
    )
    private val hindiDistractors = listOf(
        "कलम", "मेज़", "कुर्सी", "लंबा", "ऊँचा", "मोटा", "राम", "खाना", "है",
        "10", "11", "13", "चाँद", "तारा", "बादल", "दिन", "सुबह", "शाम", "दोपहर",
        "खट्टा", "कड़वा", "नमकीन", "तीखा", "पुल्लिंग", "नपुंसक", "कोई नहीं",
        "अग्नि", "वायु", "मिट्टी", "30", "35", "40", "छोटा"
    )

    private val distractorBanks: Map<Subject, List<String>> = mapOf(
        Subject.GK to gkDistractors,
        Subject.SST to sstDistractors,
        Subject.BIOLOGY to biologyDistractors,
        Subject.REASONING to reasoningDistractors,
        Subject.COMPUTER to computerDistractors,
        Subject.ENGLISH to englishDistractors,
        Subject.HINDI to hindiDistractors
    )

    /**
     * Expands a small curated fact list into thousands of question INSTANCES by combining
     * each fact's correct answer with many different random 3-distractor combinations drawn
     * from the subject's distractor bank. The underlying facts stay accurate; what varies is
     * the wrong-answer options and their order, which is how large question banks are built
     * in most quiz apps without inventing new facts.
     */
    private fun expandWithDistractors(facts: List<Question>, bank: List<String>, targetCount: Int): List<Question> {
        if (facts.isEmpty() || bank.size < 4) return facts
        val perFact = (targetCount / facts.size) + 1
        val result = ArrayList<Question>(targetCount)

        for (fact in facts) {
            val correct = fact.options[fact.correctIndex]
            val candidateBank = bank.filter { it != correct }
            val seenCombos = HashSet<Set<String>>()
            val rnd = Random(fact.question.hashCode().toLong())
            var attempts = 0
            var generated = 0
            while (generated < perFact && attempts < perFact * 6) {
                attempts++
                val distractors = candidateBank.shuffled(rnd).take(3)
                if (distractors.size < 3) break
                val comboKey = distractors.toSet()
                if (!seenCombos.add(comboKey)) continue
                val options = (distractors + correct).shuffled(rnd)
                result.add(Question(fact.question, options, options.indexOf(correct)))
                generated++
            }
        }
        return result
    }

    /** Remix mixes every other subject's EXPANDED pool into one huge shuffled bag. */
    private val remixPool: List<Question> by lazy {
        Subject.values()
            .filter { it != Subject.MATH && it != Subject.REMIX }
            .flatMap { expandedPoolFor(it) }
    }

    private val expandedPoolCache = HashMap<Subject, List<Question>>()

    private fun expandedPoolFor(subject: Subject): List<Question> {
        expandedPoolCache[subject]?.let { return it }
        val facts = poolsBySubject[subject] ?: return emptyList()
        val bank = distractorBanks[subject] ?: return facts
        val expanded = expandWithDistractors(facts, bank, TARGET_PER_SUBJECT)
        expandedPoolCache[subject] = expanded
        return expanded
    }

    fun poolFor(subject: Subject): List<Question> = when (subject) {
        Subject.REMIX -> remixPool
        Subject.MATH -> emptyList() // handled procedurally, not via pool
        else -> expandedPoolFor(subject)
    }
}
