package com.quizapp.kids.data

import android.content.Context
import com.google.gson.Gson
import kotlin.random.Random

/**
 * Loads questions for a given Class + Language + Level.
 *
 * Priority:
 * 1) Hand-written questions from assets/questions/class{N}_{lang}.json (best quality,
 *    add as many levels as you want here — see README for format).
 * 2) If that level isn't present in the JSON file yet, a procedural math question set
 *    is generated automatically so that ALL 1000 levels always work out of the box.
 *    You can gradually replace these by adding real entries to the JSON files.
 */
class QuestionRepository(private val context: Context) {

    private val gson = Gson()
    private val cache = HashMap<String, ClassQuestionBank?>()

    private fun loadBank(classId: Int, language: String): ClassQuestionBank? {
        val key = "${classId}_$language"
        if (cache.containsKey(key)) return cache[key]
        val bank = try {
            val fileName = "questions/class${classId}_${language}.json"
            val json = context.assets.open(fileName).bufferedReader().use { it.readText() }
            gson.fromJson(json, ClassQuestionBank::class.java)
        } catch (e: Exception) {
            null
        }
        cache[key] = bank
        return bank
    }

    fun getLevel(classId: Int, language: String, level: Int): LevelData {
        val bank = loadBank(classId, language)
        val handWritten = bank?.levels?.find { it.level == level }
        if (handWritten != null && handWritten.questions.isNotEmpty()) return handWritten
        return ProceduralQuestionGenerator.generate(classId, level)
    }
}

/**
 * Generates simple, curriculum-scaled math questions so every one of the 1000 levels
 * per class always has content, even before real questions are authored.
 * Difficulty scales gently with class (1-12) and level (1-1000).
 */
object ProceduralQuestionGenerator {

    fun generate(classId: Int, level: Int): LevelData {
        val seed = classId * 100000L + level
        val rnd = Random(seed)
        val maxNumber = (10 + classId * 8 + level / 4).coerceAtMost(9999)
        val questions = (1..5).map { generateQuestion(rnd, maxNumber) }
        return LevelData(level = level, questions = questions)
    }

    private fun generateQuestion(rnd: Random, maxNumber: Int): Question {
        val a = rnd.nextInt(1, maxNumber)
        val b = rnd.nextInt(1, maxNumber)
        val opPick = rnd.nextInt(0, 3)
        val (text, correct) = when (opPick) {
            0 -> "$a + $b = ?" to (a + b)
            1 -> {
                val big = maxOf(a, b); val small = minOf(a, b)
                "$big - $small = ?" to (big - small)
            }
            else -> {
                val small1 = rnd.nextInt(1, 12); val small2 = rnd.nextInt(1, 12)
                "$small1 x $small2 = ?" to (small1 * small2)
            }
        }
        val options = mutableListOf(correct)
        while (options.size < 4) {
            val delta = rnd.nextInt(-5, 6)
            val candidate = correct + delta + if (delta == 0) rnd.nextInt(1, 4) else 0
            if (candidate >= 0 && !options.contains(candidate)) options.add(candidate)
        }
        options.shuffle(rnd)
        return Question(
            question = text,
            options = options.map { it.toString() },
            correctIndex = options.indexOf(correct)
        )
    }
}
