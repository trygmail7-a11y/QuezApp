package com.quizapp.kids.ui

import android.content.Intent
import android.os.Bundle
import com.quizapp.kids.R
import com.quizapp.kids.data.ProfileManager
import com.quizapp.kids.databinding.ActivityResultBinding
import com.quizapp.kids.util.AdManager

class ResultActivity : BaseActivity() {

    private lateinit var binding: ActivityResultBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityResultBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val classId = intent.getIntExtra(QuizActivity.EXTRA_CLASS_ID, 1)
        val level = intent.getIntExtra(QuizActivity.EXTRA_LEVEL, 1)
        val correct = intent.getIntExtra(EXTRA_CORRECT, 0)
        val total = intent.getIntExtra(EXTRA_TOTAL, 5)

        binding.textResultScore.text = getString(R.string.result_score, correct, total)

        binding.btnNextLevel.setOnClickListener {
            val profileManager = ProfileManager(this)
            val name = profileManager.getCurrentProfileName() ?: return@setOnClickListener
            val nextLevel = profileManager.getCurrentLevel(name, classId)
            val intent = Intent(this, QuizActivity::class.java)
            intent.putExtra(QuizActivity.EXTRA_CLASS_ID, classId)
            intent.putExtra(QuizActivity.EXTRA_LEVEL, nextLevel)
            startActivity(intent)
            finish()
        }

        binding.btnRetry.setOnClickListener {
            val intent = Intent(this, QuizActivity::class.java)
            intent.putExtra(QuizActivity.EXTRA_CLASS_ID, classId)
            intent.putExtra(QuizActivity.EXTRA_LEVEL, level)
            startActivity(intent)
            finish()
        }

        binding.btnHome.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }

        // Natural break point - show a full screen (video) interstitial ad here, once.
        AdManager.showInterstitialIfReady(this) { /* no-op, buttons already visible */ }
    }

    companion object {
        const val EXTRA_CORRECT = "extra_correct"
        const val EXTRA_TOTAL = "extra_total"
    }
}
