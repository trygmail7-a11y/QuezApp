package com.quizapp.kids.ui

import android.content.Intent
import android.os.Bundle
import com.quizapp.kids.R
import com.quizapp.kids.data.ProfileManager
import com.quizapp.kids.data.Subject
import com.quizapp.kids.databinding.ActivityResultBinding
import com.quizapp.kids.util.AdManager

class ResultActivity : BaseActivity() {

    private lateinit var binding: ActivityResultBinding
    private lateinit var profileManager: ProfileManager
    private lateinit var subject: Subject
    private var classId = 1
    private var level = 1
    private var correct = 0
    private var total = 5
    private var wrongCount = 0
    private var failed = false
    private var stars = 0
    private var name = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityResultBinding.inflate(layoutInflater)
        setContentView(binding.root)

        profileManager = ProfileManager(this)
        subject = Subject.fromId(intent.getStringExtra(QuizActivity.EXTRA_SUBJECT) ?: Subject.MATH.id)
        classId = intent.getIntExtra(QuizActivity.EXTRA_CLASS_ID, 1)
        level = intent.getIntExtra(QuizActivity.EXTRA_LEVEL, 1)
        correct = intent.getIntExtra(EXTRA_CORRECT, 0)
        total = intent.getIntExtra(EXTRA_TOTAL, 5)
        wrongCount = intent.getIntExtra(EXTRA_WRONG_COUNT, 0)
        failed = intent.getBooleanExtra(EXTRA_FAILED, false)
        name = profileManager.getCurrentProfileName() ?: ""

        binding.textResultScore.text = getString(R.string.result_score, correct, total)

        if (failed) {
            setupFailedState()
        } else {
            stars = profileManager.starsFromWrongCount(wrongCount)
            setupSuccessState()
        }

        binding.btnRetry.setOnClickListener { retryLevel() }
        binding.btnHome.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }
    }

    private fun setupFailedState() {
        binding.textResultTitle.text = getString(R.string.result_failed_title)
        binding.textResultScore.text = getString(R.string.result_failed_message)
        binding.starsResultRow.visibility = android.view.View.GONE
        binding.btnNextLevel.visibility = android.view.View.GONE
    }

    private fun setupSuccessState() {
        binding.textResultTitle.text = getString(R.string.result_title)
        binding.starsResultRow.visibility = android.view.View.VISIBLE
        binding.resultStar1.setImageResource(if (stars >= 1) R.drawable.ic_star_filled else R.drawable.ic_star_outline)
        binding.resultStar2.setImageResource(if (stars >= 2) R.drawable.ic_star_filled else R.drawable.ic_star_outline)
        binding.resultStar3.setImageResource(if (stars >= 3) R.drawable.ic_star_filled else R.drawable.ic_star_outline)

        binding.btnNextLevel.setOnClickListener {
            // Watch a rewarded video ad to unlock the next level.
            // If no ad is available (e.g. offline), we unlock anyway so the child is never stuck.
            AdManager.showRewardedAd(
                activity = this,
                onRewardEarned = { unlockNextLevelAndContinue() },
                onAdUnavailable = { unlockNextLevelAndContinue() }
            )
        }
    }

    private fun unlockNextLevelAndContinue() {
        val newLevel = profileManager.advanceToNextLevel(name, subject, classId, level, stars)

        val goToNextLevel = {
            val intent = Intent(this, QuizActivity::class.java)
            intent.putExtra(QuizActivity.EXTRA_SUBJECT, subject.id)
            intent.putExtra(QuizActivity.EXTRA_CLASS_ID, classId)
            intent.putExtra(QuizActivity.EXTRA_LEVEL, newLevel)
            startActivity(intent)
            finish()
        }

        // Every 5 completed levels within this subject, also show the milestone video ad.
        if (profileManager.isMilestoneLevel(level)) {
            AdManager.showMilestoneAdIfReady(this) { goToNextLevel() }
        } else {
            goToNextLevel()
        }
    }

    private fun retryLevel() {
        val intent = Intent(this, QuizActivity::class.java)
        intent.putExtra(QuizActivity.EXTRA_SUBJECT, subject.id)
        intent.putExtra(QuizActivity.EXTRA_CLASS_ID, classId)
        intent.putExtra(QuizActivity.EXTRA_LEVEL, level)
        startActivity(intent)
        finish()
    }

    companion object {
        const val EXTRA_CORRECT = "extra_correct"
        const val EXTRA_TOTAL = "extra_total"
        const val EXTRA_WRONG_COUNT = "extra_wrong_count"
        const val EXTRA_FAILED = "extra_failed"
    }
}
