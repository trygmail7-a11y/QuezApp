package com.quizapp.kids.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import com.quizapp.kids.R
import com.quizapp.kids.data.ProfileManager
import com.quizapp.kids.data.Subject
import com.quizapp.kids.databinding.ActivityResultBinding
import com.quizapp.kids.util.AdManager

class ResultActivity : BaseActivity() {

    private lateinit var binding: ActivityResultBinding
    private lateinit var profileManager: ProfileManager
    private lateinit var subject: Subject
    private var classId = 1
    private var level = 1
    private var correct = 0
    private var total = 5
    private var wrongCount = 0
    private var failed = false
    private var stars = 0
    private var name = ""
    private var actionInProgress = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityResultBinding.inflate(layoutInflater)
        setContentView(binding.root)

        profileManager = ProfileManager(this)
        subject = Subject.fromId(intent.getStringExtra(QuizActivity.EXTRA_SUBJECT) ?: Subject.MATH.id)
        classId = intent.getIntExtra(QuizActivity.EXTRA_CLASS_ID, 1)
        level = intent.getIntExtra(QuizActivity.EXTRA_LEVEL, 1)
        correct = intent.getIntExtra(EXTRA_CORRECT, 0)
        total = intent.getIntExtra(EXTRA_TOTAL, 5)
        wrongCount = intent.getIntExtra(EXTRA_WRONG_COUNT, 0)
        failed = intent.getBooleanExtra(EXTRA_FAILED, false)
        name = profileManager.getCurrentProfileName() ?: ""

        binding.textResultScore.text = getString(R.string.result_score, correct, total)

        if (failed) {
            setupFailedState()
        } else {
            stars = profileManager.starsFromWrongCount(wrongCount)
            setupSuccessState()
        }

        binding.btnRetry.setOnClickListener {
            if (actionInProgress || isFinishing || isDestroyed) return@setOnClickListener
            actionInProgress = true
            retryLevel()
        }
        binding.btnHome.setOnClickListener {
            if (actionInProgress || isFinishing || isDestroyed) return@setOnClickListener
            actionInProgress = true
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }
    }

    /**
     * Failed the level (more than 2 wrong answers): no free "Next Level" button here.
     * Instead the child can either Retry the same level for free, or watch a video ad
     * to skip ahead to the next level anyway despite not clearing it.
     */
    private fun setupFailedState() {
        binding.textResultTitle.text = getString(R.string.result_failed_title)
        binding.textResultScore.text = getString(R.string.result_failed_message)
        binding.starsResultRow.visibility = View.GONE
        binding.btnNextLevel.visibility = View.GONE

        binding.btnWatchAdSkip.visibility = View.VISIBLE
        binding.btnWatchAdSkip.setOnClickListener {
            if (actionInProgress || isFinishing || isDestroyed) return@setOnClickListener
            actionInProgress = true
            AdManager.showRewardedAd(
                activity = this,
                onRewardEarned = { advanceWithoutMilestoneCheck(starsToSave = 0) },
                onAdUnavailable = { advanceWithoutMilestoneCheck(starsToSave = 0) }
            )
        }
    }

    /**
     * Passed the level (0-2 wrong answers): show stars earned and a plain, free
     * "Next Level" button — no ad here at all.
     */
    private fun setupSuccessState() {
        binding.textResultTitle.text = getString(R.string.result_title)
        binding.starsResultRow.visibility = View.VISIBLE
        binding.resultStar1.setImageResource(if (stars >= 1) R.drawable.ic_star_filled else R.drawable.ic_star_outline)
        binding.resultStar2.setImageResource(if (stars >= 2) R.drawable.ic_star_filled else R.drawable.ic_star_outline)
        binding.resultStar3.setImageResource(if (stars >= 3) R.drawable.ic_star_filled else R.drawable.ic_star_outline)
        binding.btnWatchAdSkip.visibility = View.GONE

        binding.btnNextLevel.setOnClickListener {
            if (actionInProgress || isFinishing || isDestroyed) return@setOnClickListener
            actionInProgress = true
            val newLevel = profileManager.advanceToNextLevel(name, subject, classId, level, stars)
            val goToNextLevel = { startQuiz(newLevel) }

            // Only ad in the success path: an automatic milestone video every 5 completed levels.
            if (profileManager.isMilestoneLevel(level)) {
                AdManager.showMilestoneAdIfReady(this) { goToNextLevel() }
            } else {
                goToNextLevel()
            }
        }
    }

    private fun advanceWithoutMilestoneCheck(starsToSave: Int) {
        val newLevel = profileManager.advanceToNextLevel(name, subject, classId, level, starsToSave)
        startQuiz(newLevel)
    }

    private fun startQuiz(level: Int) {
        val intent = Intent(this, QuizActivity::class.java)
        intent.putExtra(QuizActivity.EXTRA_SUBJECT, subject.id)
        intent.putExtra(QuizActivity.EXTRA_CLASS_ID, classId)
        intent.putExtra(QuizActivity.EXTRA_LEVEL, level)
        startActivity(intent)
        finish()
    }

    private fun retryLevel() {
        startQuiz(level)
    }

    companion object {
        const val EXTRA_CORRECT = "extra_correct"
        const val EXTRA_TOTAL = "extra_total"
        const val EXTRA_WRONG_COUNT = "extra_wrong_count"
        const val EXTRA_FAILED = "extra_failed"
    }
}
