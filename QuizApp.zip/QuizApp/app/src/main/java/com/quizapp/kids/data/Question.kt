package com.quizapp.kids.data

/**
 * Represents one quiz question.
 * options[] has 4 choices, correctIndex points to the right one (0-3).
 */
data class Question(
    val question: String,
    val options: List<String>,
    val correctIndex: Int
)

/**
 * A level bundles a small set of questions (we ask 5 per level;
 * 5 correct answers in a row pushes the user to the next level).
 */
data class LevelData(
    val level: Int,
    val questions: List<Question>
)

/**
 * Root JSON structure stored per class+language file, e.g. class1_hi.json
 */
data class ClassQuestionBank(
    val classId: Int,
    val language: String,
    val levels: List<LevelData>
)
