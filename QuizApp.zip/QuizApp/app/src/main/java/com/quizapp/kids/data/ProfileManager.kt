package com.quizapp.kids.data

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

/**
 * Handles ALL local data storage — no server, no login, no internet needed for data.
 * Supports MULTIPLE profiles on the same device (e.g. 2 brothers, different classes),
 * each profile keeps its own class, language, current subject and per-subject-per-class
 * level progress + star ratings.
 */
class ProfileManager(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("quiz_app_data", Context.MODE_PRIVATE)
    private val gson = Gson()

    companion object {
        const val MAX_LEVEL = 1000
        const val MAX_HEARTS = 2 // 2 mistakes allowed per level attempt
        const val QUESTIONS_PER_LEVEL = 5
        const val LEVELS_PER_MILESTONE_AD = 5
        private const val KEY_CURRENT_PROFILE = "current_profile"
        private const val KEY_ALL_PROFILES = "all_profiles"
    }

    // ---------- Profile (child) management ----------

    fun getAllProfileNames(): Set<String> =
        prefs.getStringSet(KEY_ALL_PROFILES, emptySet()) ?: emptySet()

    fun getCurrentProfileName(): String? = prefs.getString(KEY_CURRENT_PROFILE, null)

    fun setCurrentProfileName(name: String) {
        prefs.edit().putString(KEY_CURRENT_PROFILE, name).apply()
        val all = getAllProfileNames().toMutableSet()
        all.add(name)
        prefs.edit().putStringSet(KEY_ALL_PROFILES, all).apply()
    }

    fun getProfileClass(name: String): Int = prefs.getInt("profile_${name}_class", -1)

    fun setProfileClass(name: String, classId: Int) {
        prefs.edit().putInt("profile_${name}_class", classId).apply()
    }

    fun getProfileLanguage(name: String): String =
        prefs.getString("profile_${name}_lang", "en") ?: "en"

    fun setProfileLanguage(name: String, langCode: String) {
        prefs.edit().putString("profile_${name}_lang", langCode).apply()
    }

    fun getCurrentSubject(name: String): Subject {
        val id = prefs.getString("profile_${name}_subject", Subject.MATH.id) ?: Subject.MATH.id
        return Subject.fromId(id)
    }

    fun setCurrentSubject(name: String, subject: Subject) {
        prefs.edit().putString("profile_${name}_subject", subject.id).apply()
    }

    // ---------- Level progress (per profile + per subject + per class) ----------

    private fun key(name: String, subject: Subject, classId: Int, suffix: String) =
        "progress_${name}_${subject.id}_${classId}_$suffix"

    fun getCurrentLevel(name: String, subject: Subject, classId: Int): Int =
        prefs.getInt(key(name, subject, classId, "level"), 1).coerceIn(1, MAX_LEVEL)

    fun getTotalScore(name: String, subject: Subject, classId: Int): Int =
        prefs.getInt(key(name, subject, classId, "score"), 0)

    fun getHighestUnlockedLevel(name: String, subject: Subject, classId: Int): Int =
        prefs.getInt(key(name, subject, classId, "unlocked"), 1).coerceIn(1, MAX_LEVEL)

    fun addScore(name: String, subject: Subject, classId: Int, correctAnswers: Int) {
        val newScore = getTotalScore(name, subject, classId) + correctAnswers
        prefs.edit().putInt(key(name, subject, classId, "score"), newScore).apply()
    }

    /**
     * Called only AFTER the reward video ad has been watched successfully.
     * Advances to the next level and saves the star rating earned for the level just finished.
     * Returns the new current level.
     */
    fun advanceToNextLevel(name: String, subject: Subject, classId: Int, finishedLevel: Int, starsEarned: Int): Int {
        saveStars(name, subject, classId, finishedLevel, starsEarned)
        val newLevel = (finishedLevel + 1).coerceAtMost(MAX_LEVEL)
        val edit = prefs.edit()
        edit.putInt(key(name, subject, classId, "level"), newLevel)
        val unlocked = getHighestUnlockedLevel(name, subject, classId)
        if (newLevel > unlocked) {
            edit.putInt(key(name, subject, classId, "unlocked"), newLevel)
        }
        edit.apply()
        return newLevel
    }

    fun jumpToLevel(name: String, subject: Subject, classId: Int, level: Int) {
        val safeLevel = level.coerceIn(1, getHighestUnlockedLevel(name, subject, classId))
        prefs.edit().putInt(key(name, subject, classId, "level"), safeLevel).apply()
    }

    /** true if this finished level (1-indexed count of levels completed) should trigger the milestone ad. */
    fun isMilestoneLevel(finishedLevel: Int): Boolean = finishedLevel % LEVELS_PER_MILESTONE_AD == 0

    // ---------- Star ratings (1-3 stars per completed level, shown in the level map) ----------

    private fun starsKey(name: String, subject: Subject, classId: Int) =
        "stars_${name}_${subject.id}_$classId"

    fun getStarsMap(name: String, subject: Subject, classId: Int): Map<Int, Int> {
        val json = prefs.getString(starsKey(name, subject, classId), null) ?: return emptyMap()
        return try {
            val type = object : TypeToken<Map<Int, Int>>() {}.type
            gson.fromJson(json, type) ?: emptyMap()
        } catch (e: Exception) {
            emptyMap()
        }
    }

    fun getStarsForLevel(name: String, subject: Subject, classId: Int, level: Int): Int =
        getStarsMap(name, subject, classId)[level] ?: 0

    private fun saveStars(name: String, subject: Subject, classId: Int, level: Int, stars: Int) {
        val current = getStarsMap(name, subject, classId).toMutableMap()
        val best = maxOf(current[level] ?: 0, stars)
        current[level] = best
        prefs.edit().putString(starsKey(name, subject, classId), gson.toJson(current)).apply()
    }

    /** Converts a wrong-answer count (0, 1, or 2) into a star rating (3, 2, or 1). */
    fun starsFromWrongCount(wrongCount: Int): Int = (MAX_HEARTS + 1 - wrongCount).coerceIn(1, 3)

    // ---------- Question no-repeat system ----------
    // Once a question has been shown in ANY level of a subject, it will not be shown again
    // until every other question in that subject's pool has also been used at least once.
    // A level's exact question set is cached the first time it's played, so retrying the
    // SAME level always shows the SAME questions again (that's expected on retry).

    private fun levelCacheKey(name: String, subject: Subject, classId: Int, language: String, level: Int) =
        "qcache_${name}_${subject.id}_${classId}_${language}_$level"

    private fun usedPoolKey(name: String, subject: Subject, classId: Int, language: String) =
        "qused_${name}_${subject.id}_${classId}_$language"

    fun getCachedLevelQuestions(name: String, subject: Subject, classId: Int, language: String, level: Int): List<Question>? {
        val json = prefs.getString(levelCacheKey(name, subject, classId, language, level), null) ?: return null
        return try {
            val type = object : TypeToken<List<Question>>() {}.type
            gson.fromJson(json, type)
        } catch (e: Exception) {
            null
        }
    }

    fun saveCachedLevelQuestions(name: String, subject: Subject, classId: Int, language: String, level: Int, questions: List<Question>) {
        prefs.edit()
            .putString(levelCacheKey(name, subject, classId, language, level), gson.toJson(questions))
            .apply()
    }

    fun getUsedQuestionHashes(name: String, subject: Subject, classId: Int, language: String): Set<String> =
        prefs.getStringSet(usedPoolKey(name, subject, classId, language), emptySet()) ?: emptySet()

    fun markQuestionHashesUsed(name: String, subject: Subject, classId: Int, language: String, hashes: List<String>) {
        val current = getUsedQuestionHashes(name, subject, classId, language).toMutableSet()
        current.addAll(hashes)
        prefs.edit().putStringSet(usedPoolKey(name, subject, classId, language), current).apply()
    }

    fun resetUsedQuestionHashes(name: String, subject: Subject, classId: Int, language: String) {
        prefs.edit().remove(usedPoolKey(name, subject, classId, language)).apply()
    }
}
