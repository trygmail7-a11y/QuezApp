package com.quizapp.kids.data

import android.content.Context
import android.content.SharedPreferences

/**
 * Handles ALL local data storage — no server, no login, no internet needed for data.
 * Supports MULTIPLE profiles on the same device (e.g. 2 brothers, different classes),
 * each profile keeps its own class, language and per-class level progress.
 */
class ProfileManager(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("quiz_app_data", Context.MODE_PRIVATE)

    companion object {
        const val MAX_LEVEL = 1000
        const val CORRECT_TO_LEVEL_UP = 5
        private const val KEY_CURRENT_PROFILE = "current_profile"
        private const val KEY_ALL_PROFILES = "all_profiles"
    }

    // ---------- Profile (child) management ----------

    fun getAllProfileNames(): Set<String> =
        prefs.getStringSet(KEY_ALL_PROFILES, emptySet()) ?: emptySet()

    fun getCurrentProfileName(): String? = prefs.getString(KEY_CURRENT_PROFILE, null)

    fun setCurrentProfileName(name: String) {
        prefs.edit().putString(KEY_CURRENT_PROFILE, name).apply()
        val all = getAllProfileNames().toMutableSet()
        all.add(name)
        prefs.edit().putStringSet(KEY_ALL_PROFILES, all).apply()
    }

    fun getProfileClass(name: String): Int = prefs.getInt("profile_${name}_class", -1)

    fun setProfileClass(name: String, classId: Int) {
        prefs.edit().putInt("profile_${name}_class", classId).apply()
    }

    fun getProfileLanguage(name: String): String =
        prefs.getString("profile_${name}_lang", "en") ?: "en"

    fun setProfileLanguage(name: String, langCode: String) {
        prefs.edit().putString("profile_${name}_lang", langCode).apply()
    }

    // ---------- Level progress (per profile + per class, since a child could technically
    // switch class from the profile chip and each class keeps its own 1000-level progress) ----------

    fun getCurrentLevel(name: String, classId: Int): Int =
        prefs.getInt("progress_${name}_${classId}_level", 1).coerceIn(1, MAX_LEVEL)

    fun getCorrectStreakInLevel(name: String, classId: Int): Int =
        prefs.getInt("progress_${name}_${classId}_streak", 0)

    fun getTotalScore(name: String, classId: Int): Int =
        prefs.getInt("progress_${name}_${classId}_score", 0)

    fun getHighestUnlockedLevel(name: String, classId: Int): Int =
        prefs.getInt("progress_${name}_${classId}_unlocked", 1).coerceIn(1, MAX_LEVEL)

    /** Call after each answered question. Returns true if the level just advanced. */
    fun recordAnswer(name: String, classId: Int, wasCorrect: Boolean): Boolean {
        val edit = prefs.edit()
        var leveledUp = false
        if (wasCorrect) {
            val score = getTotalScore(name, classId) + 1
            edit.putInt("progress_${name}_${classId}_score", score)

            val streak = getCorrectStreakInLevel(name, classId) + 1
            if (streak >= CORRECT_TO_LEVEL_UP) {
                val newLevel = (getCurrentLevel(name, classId) + 1).coerceAtMost(MAX_LEVEL)
                edit.putInt("progress_${name}_${classId}_level", newLevel)
                val unlocked = getHighestUnlockedLevel(name, classId)
                if (newLevel > unlocked) {
                    edit.putInt("progress_${name}_${classId}_unlocked", newLevel)
                }
                edit.putInt("progress_${name}_${classId}_streak", 0)
                leveledUp = true
            } else {
                edit.putInt("progress_${name}_${classId}_streak", streak)
            }
        } else {
            // wrong answer resets the current 5-question streak, but does not remove level progress
            edit.putInt("progress_${name}_${classId}_streak", 0)
        }
        edit.apply()
        return leveledUp
    }

    fun jumpToLevel(name: String, classId: Int, level: Int) {
        val safeLevel = level.coerceIn(1, getHighestUnlockedLevel(name, classId))
        prefs.edit()
            .putInt("progress_${name}_${classId}_level", safeLevel)
            .putInt("progress_${name}_${classId}_streak", 0)
            .apply()
    }
}
