package com.quizapp.kids.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.quizapp.kids.R
import com.quizapp.kids.databinding.ItemLevelBinding

class LevelAdapter(
    private val totalLevels: Int,
    private val highestUnlocked: Int,
    private val currentLevel: Int,
    private val onLevelClick: (Int) -> Unit
) : RecyclerView.Adapter<LevelAdapter.LevelViewHolder>() {

    inner class LevelViewHolder(val binding: ItemLevelBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LevelViewHolder {
        val binding = ItemLevelBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return LevelViewHolder(binding)
    }

    override fun onBindViewHolder(holder: LevelViewHolder, position: Int) {
        val level = position + 1
        val isUnlocked = level <= highestUnlocked
        val isCompleted = level < currentLevel

        holder.binding.textLevelNumber.text = level.toString()
        holder.binding.iconLock.visibility = if (isUnlocked) android.view.View.GONE else android.view.View.VISIBLE
        holder.binding.textLevelNumber.text = if (isUnlocked) level.toString() else ""

        val bg = when {
            isCompleted -> R.drawable.bg_level_completed
            isUnlocked -> R.drawable.bg_level_unlocked
            else -> R.drawable.bg_level_locked
        }
        holder.binding.textLevelNumber.setBackgroundResource(bg)

        holder.binding.root.setOnClickListener {
            if (isUnlocked) onLevelClick(level)
        }
        holder.binding.root.alpha = if (isUnlocked) 1f else 0.7f
    }

    override fun getItemCount(): Int = totalLevels
}
