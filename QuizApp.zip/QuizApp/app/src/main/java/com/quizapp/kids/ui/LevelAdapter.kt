package com.quizapp.kids.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.quizapp.kids.R
import com.quizapp.kids.databinding.ItemLevelBinding

class LevelAdapter(
    private val totalLevels: Int,
    private val highestUnlocked: Int,
    private val currentLevel: Int,
    private val starsForLevel: (Int) -> Int,
    private val onLevelClick: (Int) -> Unit
) : RecyclerView.Adapter<LevelAdapter.LevelViewHolder>() {

    inner class LevelViewHolder(val binding: ItemLevelBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LevelViewHolder {
        val binding = ItemLevelBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return LevelViewHolder(binding)
    }

    override fun onBindViewHolder(holder: LevelViewHolder, position: Int) {
        val level = position + 1
        val isUnlocked = level <= highestUnlocked
        val isCompleted = level < currentLevel

        holder.binding.iconLock.visibility = if (isUnlocked) View.GONE else View.VISIBLE
        holder.binding.textLevelNumber.text = if (isUnlocked) level.toString() else ""

        val bg = when {
            isCompleted -> R.drawable.bg_level_completed
            isUnlocked -> R.drawable.bg_level_unlocked
            else -> R.drawable.bg_level_locked
        }
        holder.binding.textLevelNumber.setBackgroundResource(bg)

        val stars = if (isUnlocked) starsForLevel(level) else 0
        holder.binding.star1.setImageResource(if (stars >= 1) R.drawable.ic_star_filled else R.drawable.ic_star_outline)
        holder.binding.star2.setImageResource(if (stars >= 2) R.drawable.ic_star_filled else R.drawable.ic_star_outline)
        holder.binding.star3.setImageResource(if (stars >= 3) R.drawable.ic_star_filled else R.drawable.ic_star_outline)
        holder.binding.starsRow.visibility = if (isCompleted) View.VISIBLE else View.INVISIBLE

        holder.itemView.setOnClickListener {
            if (isUnlocked) onLevelClick(level)
        }
        holder.itemView.alpha = if (isUnlocked) 1f else 0.7f
    }

    override fun getItemCount(): Int = totalLevels
}
