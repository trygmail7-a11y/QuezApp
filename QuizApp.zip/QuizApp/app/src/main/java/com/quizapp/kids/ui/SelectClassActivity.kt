package com.quizapp.kids.ui

import android.content.Intent
import android.os.Bundle
import androidx.recyclerview.widget.GridLayoutManager
import com.quizapp.kids.data.ProfileManager
import com.quizapp.kids.databinding.ActivitySelectClassBinding

/**
 * First screen: choose Class 1 to Class 10.
 * Chosen class is stored against the CURRENT profile only (so 2 brothers on the
 * same phone keep separate class + progress once they each pick their own name).
 */
class SelectClassActivity : BaseActivity() {

    private lateinit var binding: ActivitySelectClassBinding
    private var pendingClassId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySelectClassBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val classNames = (1..10).map { "Class $it" }
        binding.recyclerClasses.layoutManager = GridLayoutManager(this, 3)
        binding.recyclerClasses.adapter = ClassAdapter(classNames) { classId ->
            pendingClassId = classId
            goToNameSelection(classId)
        }
    }

    private fun goToNameSelection(classId: Int) {
        val intent = Intent(this, SelectNameActivity::class.java)
        intent.putExtra(EXTRA_CLASS_ID, classId)
        startActivity(intent)
    }

    companion object {
        const val EXTRA_CLASS_ID = "extra_class_id"
    }
}
