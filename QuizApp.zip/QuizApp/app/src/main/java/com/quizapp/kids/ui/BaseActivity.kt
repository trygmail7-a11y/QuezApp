package com.quizapp.kids.ui

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import com.quizapp.kids.data.ProfileManager
import com.quizapp.kids.util.LanguageManager

open class BaseActivity : AppCompatActivity() {

    override fun attachBaseContext(newBase: Context) {
        val profileManager = ProfileManager(newBase)
        val currentProfile = profileManager.getCurrentProfileName()
        val lang = if (currentProfile != null) {
            profileManager.getProfileLanguage(currentProfile)
        } else {
            "en"
        }
        super.attachBaseContext(LanguageManager.wrapContext(newBase, lang))
    }
}
