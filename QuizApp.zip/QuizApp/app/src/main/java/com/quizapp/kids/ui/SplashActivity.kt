package com.quizapp.kids.ui

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import com.quizapp.kids.R
import com.quizapp.kids.data.ProfileManager
import com.quizapp.kids.util.AdManager

class SplashActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        // Ads need internet - safe to init here, does not block offline usage of the quiz itself.
        AdManager.init(applicationContext)

        Handler(Looper.getMainLooper()).postDelayed({
            val profileManager = ProfileManager(this)
            val currentName = profileManager.getCurrentProfileName()
            val nextIntent = if (currentName != null && profileManager.getProfileClass(currentName) != -1) {
                Intent(this, HomeActivity::class.java)
            } else {
                Intent(this, SelectClassActivity::class.java)
            }
            startActivity(nextIntent)
            finish()
        }, 1200)
    }
}
