package com.quizapp.kids.ui

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import com.quizapp.kids.R
import com.quizapp.kids.data.ProfileManager
import com.quizapp.kids.data.Question
import com.quizapp.kids.data.QuestionRepository
import com.quizapp.kids.data.Subject
import com.quizapp.kids.databinding.ActivityQuizBinding
import com.quizapp.kids.databinding.ItemOptionBinding

class QuizActivity : BaseActivity() {

    private lateinit var binding: ActivityQuizBinding
    private lateinit var profileManager: ProfileManager
    private lateinit var repository: QuestionRepository

    private lateinit var subject: Subject
    private var classId = 1
    private var level = 1
    private var questions: List<Question> = emptyList()
    private var currentIndex = 0
    private var correctCount = 0
    private var wrongCount = 0
    private var answerLocked = false
    private var name = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityQuizBinding.inflate(layoutInflater)
        setContentView(binding.root)

        profileManager = ProfileManager(this)
        repository = QuestionRepository(this, profileManager)

        subject = Subject.fromId(intent.getStringExtra(EXTRA_SUBJECT) ?: Subject.MATH.id)
        classId = intent.getIntExtra(EXTRA_CLASS_ID, 1)
        level = intent.getIntExtra(EXTRA_LEVEL, 1)
        name = profileManager.getCurrentProfileName() ?: return

        val language = profileManager.getProfileLanguage(name)
        questions = repository.getLevel(subject, classId, language, level, name).questions

        binding.btnClose.setOnClickListener { finish() }
        binding.progressBar.max = questions.size

        showQuestion()
    }

    private fun showQuestion() {
        answerLocked = false
        val q = questions[currentIndex]
        binding.textProgress.text = getString(R.string.quiz_question_of, currentIndex + 1, questions.size)
        binding.progressBar.progress = currentIndex
        binding.textQuestion.text = q.question
        updateHeartsDisplay()

        binding.optionsContainer.removeAllViews()
        q.options.forEachIndexed { index, optionText ->
            val optBinding = ItemOptionBinding.inflate(LayoutInflater.from(this), binding.optionsContainer, false)
            optBinding.textOption.text = optionText
            optBinding.textOption.setOnClickListener {
                if (!answerLocked) handleAnswer(index, q.correctIndex, optBinding)
            }
            binding.optionsContainer.addView(optBinding.root)
        }
    }

    private fun updateHeartsDisplay() {
        binding.heart1.setImageResource(
            if (wrongCount < 1) R.drawable.ic_heart_filled else R.drawable.ic_heart_empty
        )
        binding.heart2.setImageResource(
            if (wrongCount < 2) R.drawable.ic_heart_filled else R.drawable.ic_heart_empty
        )
    }

    private fun handleAnswer(chosenIndex: Int, correctIndex: Int, chosenBinding: ItemOptionBinding) {
        answerLocked = true
        val isCorrect = chosenIndex == correctIndex
        chosenBinding.textOption.setBackgroundResource(
            if (isCorrect) R.drawable.bg_option_correct else R.drawable.bg_option_wrong
        )

        if (!isCorrect) {
            for (i in 0 until binding.optionsContainer.childCount) {
                val child = binding.optionsContainer.getChildAt(i)
                val text = (child as? android.widget.TextView)?.text?.toString()
                if (text == questions[currentIndex].options[correctIndex]) {
                    child.setBackgroundResource(R.drawable.bg_option_correct)
                }
            }
        }

        if (isCorrect) {
            correctCount++
        } else {
            wrongCount++
        }
        updateHeartsDisplay()

        Handler(Looper.getMainLooper()).postDelayed({
            // More than MAX_HEARTS (2) wrong answers -> fail the level immediately.
            if (wrongCount > ProfileManager.MAX_HEARTS) {
                goToResult(failed = true)
                return@postDelayed
            }
            currentIndex++
            if (currentIndex < questions.size) {
                showQuestion()
            } else {
                goToResult(failed = false)
            }
        }, 900)
    }

    private fun goToResult(failed: Boolean) {
        if (!failed) {
            profileManager.addScore(name, subject, classId, correctCount)
        }
        val intent = Intent(this, ResultActivity::class.java)
        intent.putExtra(EXTRA_SUBJECT, subject.id)
        intent.putExtra(EXTRA_CLASS_ID, classId)
        intent.putExtra(EXTRA_LEVEL, level)
        intent.putExtra(ResultActivity.EXTRA_CORRECT, correctCount)
        intent.putExtra(ResultActivity.EXTRA_TOTAL, questions.size)
        intent.putExtra(ResultActivity.EXTRA_WRONG_COUNT, wrongCount)
        intent.putExtra(ResultActivity.EXTRA_FAILED, failed)
        startActivity(intent)
        finish()
    }

    companion object {
        const val EXTRA_SUBJECT = "extra_subject"
        const val EXTRA_CLASS_ID = "extra_class_id"
        const val EXTRA_LEVEL = "extra_level"
    }
}
